#!/usr/bin/env python3

import sys

def main():
    all_nums = []
    data = sys.stdin.readlines()
    for nums in data:
        nums = int(nums.strip())
        all_nums.append(nums)
    ans_mean = mean(all_nums)
    ans_median = median(all_nums)
    print("Mean: {:.1f}".format(ans_mean))
    print("Median: {:.1f}".format(ans_median))

def mean(nums):
    total = 0
    for num in nums:
        total += num
    return total / float(len(nums))

def median(nums):
    nums.sort()
    if len(nums) % 2 == 1:
        return (nums[len(nums) // 2])
    else:
        med1 = nums[(len(nums) // 2) - 1]
        med2 = nums[len(nums) // 2]
        return (med1 + med2) / 2.0

if __name__ == '__main__':
    main()
