#!/usr/bin/env python

import os
import sys

boys = {}
girls = {}

words = sys.stdin.readlines()

with open("boys.txt") as bl:
    i = 0
    bNames = bl.readlines()
    while i < len(bNames):
        boys[bNames[i].rstrip()] = "boy"
        i += 1
with open("girls.txt") as gl:
    i = 0
    gNames = gl.readlines()
    while i < len(gNames):
        girls[gNames[i].rstrip()] = "girl"
        i += 1
i = 0
while i < len(words):
    if words[i].rstrip() in boys and words[i].rstrip() not in girls:
        print words[i].rstrip(), boys[words[i].rstrip()]
    elif words[i].rstrip() in girls and words[i].rstrip() not in boys:
        print words[i].rstrip(), girls[words[i].rstrip()]
    else:
        print words[i].rstrip(), "either"
    i += 1
