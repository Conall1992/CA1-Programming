#!/usr/bin/env python

import sys

d = {


}
i = 0
words = sys.stdin.readlines()

while i < len(words):
    if words[i] not in d:
        d[words[i]] = 0
    elif words[i] in d:
        d[words[i]] = 1
    i += 1
i = 0
for element in words:
    if d[element] == 0:
        print element.rstrip()
    i = i + 1
