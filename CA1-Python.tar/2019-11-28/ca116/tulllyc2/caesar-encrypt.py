#!/usr/bin/env python

import sys

n = 13
i = 0
j = 0
test = ""
d = {}
lower = "abcdefghijklmnopqrstuvwxyz"
upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
words = sys.stdin.readlines()
src = lower + upper
dst = lower[n:] + lower[:n] + upper[n:] + upper[:n]

while i < len(src):
    d[src[i]] = dst[i]
    i = i + 1
i = 0
j = 0
while i < len(words):
    j = 0
    test = ""
    while j < len(words[i]):

        if words[i][j] in d:
            test = test[:j] + d[words[i][j]] + test[j:]
        elif words[i][j] == " ":
            test = test + " "
        else:
            test = test + words[i][j]
        j = j + 1
    i = i + 1
    print test.rstrip()
