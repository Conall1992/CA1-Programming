#!/usr/bin/env python

import sys

i = 2
file_name = sys.argv[1]


with open(file_name, "w") as fd:
   while i < len(sys.argv):
      fd.write(sys.argv[i] + "\n")
      i = i + 1
