#!/usr/bin/env python

import sys

total = 0

file_name = "some-file.txt"
with open(file_name) as fd:
   line = fd.readline()
   while 0 < len(line):
      total = total + int(line)
      line = fd.readline()
print total 
