#!/usr/bin/env python


import sys

n = 20
plot = {}
lines = sys.stdin.readlines()
i = 0
while i < len(lines):
    token = lines[i].split()
    key = token[0] + "-" + token[1]
    plot[key] = True
    i = i + 1
print plot


i = 0

def should_plot(x, y):
    key = str(x) + "-" + str(y)
    return key in plot

print " " + "*" * n


while i < n:
    y = n - i - 1
    line = " "
    x = 0
    while x < n:
        if should_plot(x, y):
            line = line + "*"
        else:
            line = line + " " 
        x = x + 1
    print "|" + line + "|"
    i = i + 1

print " " + "*" * n
