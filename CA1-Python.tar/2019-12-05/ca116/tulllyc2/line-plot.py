#!/usr/bin/env python


import sys

n = 20
plot = {}
x1 = float(sys.argv[1])
y1 = float(sys.argv[2])
x2 = float(sys.argv[3])
y2 = float (sys.argv[4])

m = (y1 - y2) / (x1 - x2)
c = y1 - m * x1
i = 0



i = 0

def should_plot(x, y):
    if y2 < x:
        return False
    
  
    return y == int(m * x + c)

print " " + "-" * n

i = 0
while i < n:
    y = n - i - 1
    line = ""
    x = 0
    while x < n:
        if should_plot(x, y):
            line = line + "*"
        else:
            line = line + " "
        x = x + 1
    print "|" + line + "|"
    i = i + 1

print " " + "-" * n
