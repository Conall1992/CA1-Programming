#!/usr/bin/env python3

import sys

def main():
    # lines = sys.stdin.readlines()
    d = {}
    excluded = []
    for line in sys.stdin:
        tokens = line.split(":")
        names, marks = tokens[0], tokens[1]
        try:
            final_score = [int(num.strip()) for num in marks.split(",")]
            d[names] = sum(final_score)
        except:
            excluded.append(names)
            continue

    for k, v in sorted(d.items(), key=lambda values: values[1], reverse=True):
        print("{} : {}".format(k, v))

    print("Skipped:")
    for name in excluded:
        print(name)

if __name__ == '__main__':
    main()
