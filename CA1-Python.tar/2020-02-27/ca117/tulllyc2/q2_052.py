#!/usr/bin/env python3

import sys

def main():
    vowels = "aeiou"
    lines = sys.stdin.readlines()
    for line in lines:
        s = [char for char in line.lower() if char in vowels]
        if "".join(s) == vowels:
            print(line.strip())

if __name__ == '__main__':
    main()
