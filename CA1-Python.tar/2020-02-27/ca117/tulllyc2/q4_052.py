#!/usr/bin/env python3

import sys
def main():
    d = {}
    p = {}
    file_name = sys.argv[1]

    with open(file_name) as fd:
        diet = sys.stdin.readlines()
        lines = fd.readlines()

        for line in lines:
            tokens = line.strip().rsplit(maxsplit=1)
            food, calories = tokens[0], tokens[1]
            d[food.strip()] = (calories)
        for line in diet:
            tokens = line.split(",")
            name, foods = tokens[0], tokens[1:]
            p[name] = 0
            for food in foods:
                if food.strip() in d:
                    p[name] += int(d[food.strip()])
                else:
                    p[name] += 100

        max_key = len(max(p.keys(), key=len))
        max_values = len((max(str(p.values()), key=len)))

        for k, v in sorted(p.items(), key=lambda values: values[1]):
            print("{:>{:d}s} : {:>{:d}}".format(k, max_key, v, max_values + 3))
if __name__ == '__main__':
    main()
