#!/usr/bin/env python3

import sys

rotations = sys.argv[2]
s = sys.argv[1]

def main():
    rotate = [char for char in s]
    i = 0
    while i < int(rotations):
        letter = rotate[len(rotate) - 1]
        rotate.pop()
        rotate.insert(0, letter)
        i += 1

    print("".join(rotate))

if __name__ == '__main__':
    main()
