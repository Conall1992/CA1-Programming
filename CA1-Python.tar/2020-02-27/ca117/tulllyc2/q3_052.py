#!/usr/bin/env python3

import sys

def build_dictionary(filename):
    with open(filename) as fd:
        d = {}
        lines = fd.readlines()
        for line in lines:
            lis = line.split()
            d[lis[0]] = int(lis[1])
        return d

def extract_range(d, low, high):
    nd = {}
    for element in d:
        if int(d[element]) in range(low, high):
            nd[element] = d[element]
    return nd
