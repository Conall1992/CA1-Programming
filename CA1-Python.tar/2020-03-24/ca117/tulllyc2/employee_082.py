class Employee(object):

    next_employee_number = 0 

    def __init__(self, name, hours_worked=0, hourly_rate=0.00):
        self.n = name
        self.h = hours_worked
        self.r = hourly_rate
        Employee.next_employee_number += 1

    def add_hours(self, hours):
        self.h += hours
        return self

    def __str__(self):
       return "Name: {}\nID: {}\nHours: {}\nRate: \n{}".format(self.n, Employee.next_employee_number, self.h, self.r)
