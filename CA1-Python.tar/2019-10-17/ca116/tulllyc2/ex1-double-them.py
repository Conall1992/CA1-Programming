#!/usr/bin/env python

i = 0
while i < 10:
   n = input()
   print n * 2
   i = i + 1
