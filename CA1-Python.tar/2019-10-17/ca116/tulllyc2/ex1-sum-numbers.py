#!/usr/bin/env python

n = input()
m = 0
total = 0
i = 0
while i < n:
  s = raw_input()
  if s == "one":
    m = 1
  elif s == "two":
    m = 2
  elif s == "three":
    m = 3
  elif s == "four":
    m = 4
  elif s == "five":
    m = 5
  total = total + m
  i = i + 1
print total
