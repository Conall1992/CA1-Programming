#!/usr/bin/env python

a = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
b = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
s = raw_input()
i = 0
j = 0
k = 0

while s != "end":
   while int(s) != a[j]:
      j = j + 1
   b[j] = b[j] + 1
   j = 0
   i = 0
   s = raw_input()
while k < len(b):
   print a[k], "*" * b[k]
   k = k + 1
