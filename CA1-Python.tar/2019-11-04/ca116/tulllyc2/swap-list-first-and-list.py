#!/usr/bin/env python

if __name__ == "__main__":
   a = ["dog", "cat", "mouse"]

tmp = a[len(a) - 1]
a[len(a) - 1] = a[0]
a[0] = tmp
