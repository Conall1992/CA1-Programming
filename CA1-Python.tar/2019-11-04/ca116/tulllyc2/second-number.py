#!/usr/bin/env python

s = raw_input()
count = 0
i = 0
j = 0
k = 0
while count < 2:
   while i < len(s) and not ("0" <= s[i] and s[i] <= "9"):
      i = i + 1
      if count == 1:
         j = i
   while i < len(s) and not s[i] == " ":
      i = i + 1
   count = count + 1
if j > 0 and i <= len(s):
   print s[j:i], j
