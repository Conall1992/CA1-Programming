#!/usr/bin/env python

n = input()
i = 0
while i < n:
   print n - i
   i += 1
