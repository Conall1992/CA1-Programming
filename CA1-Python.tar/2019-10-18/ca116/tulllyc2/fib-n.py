#!/usr/bin/env python

n = input()
curr = 1
prev = 0
t = 0
i = 0
while i < n:
   print prev
   t = prev
   prev = curr
   curr = t + curr
   i = i + 1
