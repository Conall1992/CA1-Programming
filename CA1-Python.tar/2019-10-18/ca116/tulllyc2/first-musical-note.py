#!/usr/bin/env python

n = raw_input()
s = "abcdefg"
t = 0
i = 0
while not s[t] == n[i]:
   if t == 6:
      t = 0
      i = i + 1
   else:
      t = t + 1
print n[i]
