#!/usr/bin/env python

x = input()
y = input()
r = input()
if ((x - 0) ** 2 + (y - 0) ** 2) < r ** 2:
   print "True"
else:
   print "False"
