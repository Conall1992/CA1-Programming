#!/usr/bin/env python

s = raw_input()
t = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
m = 0
i = 0
while not t[m] == s[i]:
   if m == 24:
      m = 0
      i = i + 1
   m = m + 1
print i
