#!/usr/bin/env python

n = raw_input()
t = 0
m = 0
i = 1

while i < len(n) + 1:
   if n[len(n) - i] == "1":
      m = m + (2 ** t) * 1
   elif n[len(n) - i] == "0":
      m = m + (2 ** t) * 0
   t = t + 1
   i = i + 1
print m
