#!/usr/bin/env python

s = raw_input()
i = 0
s = "A" + s[1 :]
print s[0]
