#!/usr/bin/env python

n = input()
s = ""
hex = "abcdef"
base = 16

while n > 0:
   m = n % base
   if m == 10:
      s = "a" + s
   elif m == 11:
      s = "b" + s
   elif m == 12:
      s = "c" + s
   elif m == 13:
      s = "d" + s
   elif m == 14:
      s = "e" + s
   elif m == 15:
      s = "f" + s
   else:
      s = str(m) + s
   n = n / base
print s
