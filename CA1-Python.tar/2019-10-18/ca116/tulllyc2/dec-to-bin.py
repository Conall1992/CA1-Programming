#!/usr/bin/env python

n = input()
s = ""
base = 2

while n > 0:
   m = n % 2
   s = str(n % 2) + s
   n = n / 2
print s
