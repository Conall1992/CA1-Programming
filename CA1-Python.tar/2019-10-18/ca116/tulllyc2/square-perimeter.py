#!/usr/bin/env python

n = input()
print n * 4
