#!/usr/bin/env python

a = []
i = 0
n = 1
s = raw_input()
while s != "end":
   a.append(s)
   s = raw_input()
while n < len(a) + 1:
   print a[len(a) - n]
   n = n + 1
