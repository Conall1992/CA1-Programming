#!/usr/bin/env python

import sys

i = 1
total = 0
while i < len(sys.argv):
   total = total + int(sys.argv[i])
   i = i + 1
print total
