#!/usr/bin/env python

import sys
i = 1
while i < len(sys.argv):
   print sys.argv[i]
   i = i + 1
