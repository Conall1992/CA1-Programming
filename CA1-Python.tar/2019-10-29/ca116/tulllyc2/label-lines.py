#!/usr/bin/env python

a = []
i = 0
n = 0
s = raw_input()
while s != "end":
   a.append(s)
   s = raw_input()
   i = i + 1
while n < len(a):
   print n, i, a[n]
   n = n + 1
