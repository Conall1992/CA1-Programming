#!/usr/bin/env python

a = []
n = 0
s = raw_input()

while s != "end":
   a.append(int(s))
   s = raw_input()
while n < len(a):
   if a[n] % 2 == 0:
      print a[n]
   n = n + 1
n = 0
while n < len(a):
   if a[n] % 2 == 1:
      print a[n]
   n = n + 1
