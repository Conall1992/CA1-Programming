#!/usr/bin/env python

a = []
n = 0
s = raw_input()
while s != "end":
   a.append(int(s))
   s = raw_input()
m = input()
while n < len(a):
   print a[n] + m
   n = n + 1
