#!/usr/bin/env python

def double(n):
   return n * 2
if __name__ == "__main__":
   print double(5)
   print double("Hello")
