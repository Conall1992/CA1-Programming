#!/usr/bin/env python

def circumference(r):
   return 2 * 3.141 * r
def area(rd):
   return 3.141 * (rd * rd)
if __name__ == "__main__":
   print circumference()
   print area()
