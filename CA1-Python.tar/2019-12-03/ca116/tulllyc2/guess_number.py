#!/usr/bin/env python

import secret_number
n = 1000

def play():

   h = 1000
   l = 0
   i = 0

   while i < 10:
      guess = secret_number.guess((h + l) / 2)
      if guess == "too-high":
         h = (h + l) / 2
      elif guess == "too-low":
         l = (h + l) / 2
      i = i + 1
