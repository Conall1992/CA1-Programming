class BankAccount(object):

    def __init__(self, balance=0.00):
        self.b = balance

    def deposit(self, amount):
        self.b = self.b + amount

    def withdraw(self, draw):
        if self.b - draw < 0:
            return print("Insufficient funds available")
        self.b = self.b - draw

    def __str__(self):
        return "Your current balance is: {:.2f} euro".format((self.b))
