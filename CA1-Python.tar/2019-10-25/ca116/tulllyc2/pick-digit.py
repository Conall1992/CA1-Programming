#!/usr/bin/env python

n = input()
m = input()
print (n % (10 ** (m + 1)) / (10 ** m))
