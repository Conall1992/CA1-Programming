#!/usr/bin/env python

s = "0"
i = 0
j = 0
total = 0
n = 0
while total != 1000:
   s = raw_input()
   while j < len(s) and s[j] != "+":
      j = j + 1
   total = int(s[:j]) + int(s[j:])
   print total
   j = 0
