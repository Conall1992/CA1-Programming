#!/usr/bin/env python

import func_bsearch

def contain(a, q):
	
	low = func_bsearch.bsearch(a, q)
	if low != 0:
		print q
	
contain([1,2,3,4,5,6,7,7,8,8], 0)