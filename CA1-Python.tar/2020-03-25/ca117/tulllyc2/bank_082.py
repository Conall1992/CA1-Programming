class BankAccount(object):

    next_account_number = 16555232
    total_lodgements = 0
    interest_rate = 0.043
    
    def __init__(self, fname, sname, balance=0.00):

        self.sname = sname
        self.fname = fname
        self.balance = balance
        self.next_account_number = BankAccount.next_account_number
        BankAccount.next_account_number += 1

    def lodge(self, n):

        self.balance += n
        return self
        BankAccount.next_account_number += 1

    def apply_interest(self):
        self.balance *= BankAccount.interest_rate
        return self

    def __iadd__(self, n):
        self.balance += n
        return self

    def __str__(self):
        full_name = self.fname + " " + self.sname 
        return "Name: {}\nAccount number: {}\nBalance {:.2f}".format(full_name, self.next_account_number, self.balance)
        