class Employee(object):

    next_employee_number = 0

    def __init__(self, name, hours_worked=0.00, hourly_rate=9.25):
        self.n = name
        self.h = hours_worked
        self.r = hourly_rate
        self.e = Employee.next_employee_number
        Employee.next_employee_number += 1

    def add_hours(self, hours):
        self.h += hours
        return self

    def __str__(self):
        wages = self.r * self.h
        return "Name: {}\nID: {}\nHours: {:.2f}\nRate: {:.2f}\nWages: {:.2f}".format(self.n, self.e, self.h, self.r, wages)
