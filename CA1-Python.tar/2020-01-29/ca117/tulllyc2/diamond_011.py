#!/usr/bin/env python3

import sys

def dtop(number):
  n = number - 1
  num_top = 0
  while num_top != number - 1:
    print((n * " ") + num_top * "* " + "*")
    num_top += 1
    n -= 1
def dbottom(number):
  n = 1
  num_bottom = number
  while num_bottom != 1:
    num_bottom -= 1
    print(n * " " + (num_bottom - 1) * "* " + 1 * "*")
    n += 1

def main():
  number = int(sys.argv[1])
  top = (dtop(number))
  print((number - 1) * "* " + "*")
  bottom = (dbottom(number))

if __name__ == '__main__':
  main()
