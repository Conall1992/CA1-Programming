#!/usr/bin/env python

import sys

d = {}
with open("translation.txt") as fd:
    pairs = fd.read().split()
    i = 0
    while i < len(pairs):
        d[pairs[i]] = pairs[i + 1]
        i = i + 2

words = sys.stdin.readlines()
i = 0

while i < len(words):
    strip = words[i].rstrip()
    if words[i].rstrip() in d:
        print (d[strip])
    i = i + 1
