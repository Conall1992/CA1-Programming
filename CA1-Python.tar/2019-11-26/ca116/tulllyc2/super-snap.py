#!/usr/bin/env python

import sys

seen = {}
words = sys.stdin.readlines()

i = 0
while i < len(words):
   if words[i] not in seen:
        seen[words[i]] == True
    elif words[i] in seen:
        print "snap:", words[i]
        i == len(words)
    i = i + 1

