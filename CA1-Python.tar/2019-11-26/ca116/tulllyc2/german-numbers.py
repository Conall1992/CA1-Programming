#!/usr/bin/env python

import sys

numbers = {
    "one": "eins",
    "two": "zwei",
    "three": "drei",
    "four": "vier",
    "five": "funf",
    "six": "sechs",
    "seven": "sieben",
    "eight": "acht",
    "nine": "neun",
    "ten": "zehn",
}

words = sys.stdin.readlines()
i = 0

while i < len(words):
    strip = words[i].rstrip()
    if words[i].rstrip() in numbers:
        print (numbers[strip])
    i = i + 1
