#!/usr/bin/env python

a = []
total = ""
s = raw_input()

while s != "end":
   a.append(s)
   s = raw_input()

n = raw_input()
p = 0
while n != "end":
   if len(n) == 0:
      print total[0:len(s) - 1]
      total = ""
   elif len(n) != 0:
      total += " "
      total += a[int(n)]
   n = raw_input()
print total[0:len(s) - 1]
