#!/usr/bin/env python

import sys

a = []
i = 1
while i < len(sys.argv):
    if int(sys.argv[i]) > 0:
        a.append(sys.argv[i])
    i = i + 1
i = 0
while i < len(a):
    print a[i]
    i = i + 1
