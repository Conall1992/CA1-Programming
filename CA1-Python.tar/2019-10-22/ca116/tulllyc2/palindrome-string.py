#!/usr/bin/env python

s = raw_input()
i = 0
m = len(s)
n = -1
while i < m - 1:
   if s[i] != s[n]:
      s = ""
   else:
      s = "palindrome"
   i = i + 1
   n = n - 1
print s
