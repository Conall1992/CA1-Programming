#!/usr/bin/env python

s = raw_input()
i = 0
t = 0
n = 0
m = len(s)
while i < m and s[i] != ".":
   i = i + 1
   j = i
   t = s[0:i]
while j < len(s):
   j = j + 1
   n = s[i + 1:j]
print t
print n
