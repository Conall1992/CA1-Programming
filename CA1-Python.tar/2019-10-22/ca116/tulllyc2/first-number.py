#!/usr/bin/env python

s = raw_input()
t = ""
i = 0
while i < len(s):
   if "0" < s[i] and s[i] < "9":
      t = t + s[i]
   i = i + 1
if t != "":
   print t
