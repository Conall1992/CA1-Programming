#!/usr/bin/env python

s = raw_input()
i = 0
while i < len(s) and not ("a" <= s[i] and s[i] <= "z"):
   i = i + 1
if i < len(s) and i != 0:
   print i
else:
   print -1
