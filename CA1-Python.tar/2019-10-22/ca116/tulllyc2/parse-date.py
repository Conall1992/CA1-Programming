#!/usr/bin/env python

s = raw_input()
i = 0
t = 0
n = 0
a = ""
b = ""
c = ""
d = ""
m = len(s)
while i < m and s[i] != " ":
   i = i + 1
   j = i + 1
   a = s[0:i]
while j < m and s[j] != " ":
   j = j + 1
   t = j + 1
   b = s[i + 1:j]
while t < m and s[t] != " ":
   t = t + 1
   n = t
   c = s[j + 1:t - 1]
while n < len(s):
   n = n + 1
   d = s[t + 1:n]
print c, b + ",", d, "(" + a + ")"
