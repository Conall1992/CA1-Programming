#!/usr/bin/env python3

import sys

def main():
    total = 0
    a = []
    first_line = sys.stdin.readline().split()
    # print(first_line)
    x, y = first_line[0], first_line[1]
    # print(y)
    lines = sys.stdin.readlines()
    for line in lines:
        if len(line) < int(y):
            total += 1
    text = "".join(lines)
    elements = list(text)

    if 1 > 0:
        for i in range(0, len(elements)):
            if elements[i] == "-":
                a.append(str(i + 1))

        alone = []
        c = []
    
        for char in a:
            
            if str(int(char) + 1) in a or str(int(char) - 1) in a:
                                next
            elif str(int(char) - (int(y) + 1)) in a or str(int(char) + (int(y) + 1)) in a:
                
                next
            else:
                alone.append(char)

            
            
            
            
        
        c = [char for char in a if str(int(char) - 1) not in a and str(int(char) + 1) not in alone]
        f = [char for char in a if str(int(char) + (int(y) + 1)) in c]
        # print(alone)
        # # print(a)
        # print(e)
        # print(alone)
        
       
    
        print(len(set(alone + f)) )
        # print(f)
        # print(g)
        # print(h)
    else:
        print(str(1))



if __name__ == '__main__':
    main()
