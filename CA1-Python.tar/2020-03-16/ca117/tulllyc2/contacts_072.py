class Contact(object):

    def __init__(self, n, p, e):

        self.n = n
        self. p = p
        self.e = e

    def __str__(self):

        return "{} {} {}".format(self.n, self.p, self.e)

class ContactList(object):

    def __init__(self, d=None):
        if d is None:
            self.d = {}
        else:
            self.d = None

    def add_contact(self, c):
        self.d[c.n] = str(c)

    def del_contact(self, n):
        if n in self.d:
            del self.d[n]

    def get_contact(self, n):
        if n in self.d:
            return self.d[n]

        return None

    def __str__(self):
        contact = "Contact list" + "\n" + "------------" + "\n"
        lis = sorted(self.d.items())
        for k, v in lis:

           contact += v + "\n"
        return contact.strip()
