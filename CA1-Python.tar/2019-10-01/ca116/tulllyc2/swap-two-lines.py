#!/usr/bin/env python

n = raw_input()
m = raw_input()
t = n
n = m
m = t
print n
print m
