#!/usr/bin/env python

m = input()
print "first:", 70 <= m
print "second:", m <= 69 and 49 < m
print "third:", m <= 49 and 40 <= m
print "fail:", m < 40
