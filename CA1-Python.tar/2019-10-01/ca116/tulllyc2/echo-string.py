#!/usr/bin/env python

n = raw_input()

print(n)
