#!/usr/bin/env python

n = input()
m = input()
print m * n
