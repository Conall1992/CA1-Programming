#!/usr/bin/env python

g = input()
p = input()
print g * 3 + p
