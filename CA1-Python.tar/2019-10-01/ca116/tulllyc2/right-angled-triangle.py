#!/usr/bin/env python

a = input()
b = input()
c = input()
print a * a == b * b + c * c
