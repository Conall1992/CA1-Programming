#!/usr/bin/env python

r = input()
print 3.141 * r ** 2
