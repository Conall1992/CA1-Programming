#!/usr/bin/env python3

import sys

lines = sys.stdin.readlines()
inputs = [line.strip() + "\n" for line in lines]
words = "".join(inputs)
# poem = poem.replace("Nothing", "@")
file = sys.argv[1]
with open(file) as fd:
    censored = [cw.strip().lower() for cw in fd]
poem = words.split(" ")
for i in range(len(poem)):
    for cw in censored:
        if (cw in poem[i].lower()):
            poem[i] = poem[i].replace(cw, "@" * len(cw))

words = " ".join(poem)
print(words.strip())
