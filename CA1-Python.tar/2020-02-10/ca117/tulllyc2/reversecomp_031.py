#!/usr/bin/env python3

import sys

lines = sys.stdin.readlines()
lis = [line.strip() for line in lines]
# print(lis)
# lis  = [newLine.strip().lower() for newLine in lines]
lis2 = [line.strip().lower() for line in lines]

def main():
    a = [line.strip() for line in lis if (bsearch(lis2, line[::-1].lower()) and len(line) > 4)]
    print(a)

def bsearch(a, target):
    start = 0
    end = len(a) - 1

    while start <= end:
        middle = (start + end) // 2
        midpoint = a[middle]
        if midpoint > target:
            end = middle - 1
        elif midpoint < target:
            start = middle + 1

        else:
            return midpoint

if __name__ == '__main__':
    main()
