#!/usr/bin/env python

upper = "ABCDEFGHIFKLMNOPQRSTUVWXYZ"
lower = "abcdefghifklmnopqrstuvwxyz"
s = raw_input()
j = 0

while s != "end":
   i = 0
   while i < len(s):
      if s[i] == upper[j]:
         s = s[:i] + lower[j] + s[i + 1:]
         j = j + 1
      elif s[i] != upper[j]:
         j = j + 1
      if j == 26:
         j = 0
         i = i + 1
   print s
   s = raw_input()
