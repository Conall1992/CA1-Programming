#!/usr/bin/env python

s = raw_input()
i = 0
start = 0
end = 0
count = 1
while end < len(s):

   while end < len(s) and s[end] != ",":
      end = end + 1
   print s[start:end]
   start = end + 1
   end = end + 1
   i = i + 1
