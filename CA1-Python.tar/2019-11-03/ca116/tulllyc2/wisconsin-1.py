#!/usr/bin/env python

s = raw_input()
i = 0
j = 0
while s != "end":
   while s[i] != ",":
      i = i + 1
   if s[i + 1:i + 3] == "WI":
      print s[0:i]
   i = 0
   s = raw_input()
