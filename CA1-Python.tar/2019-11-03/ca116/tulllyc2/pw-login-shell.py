#!/usr/bin/env python

s = raw_input()
i = 0
j = 1
total = 0
while s != "end":
   while s[i] != ":":
      i = i + 1
   while s[len(s) - j] != ":":
      j = j + 1
   print s[:i], s[len(s) - j + 1:]
   i = 0
   j = 1
   s = raw_input()
