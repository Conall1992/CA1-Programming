#!/usr/bin/env python

s = raw_input()
tmp = ""
i = 1
n = 3
j = 1
total = 0
while s != "end":
   while s[i:n] != "py":
      i = i + 1
      n = n + 1
   while s[len(s) - j] != "/":
      j = j + 1
   if tmp != s[0:n]:
      print s[len(s) - j + 1:n]
   tmp = s[0:n]
   n = 3
   j = 1
   i = 1
   s = raw_input()
