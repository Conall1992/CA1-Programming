#!/usr/bin/env python

a = []
s = raw_input()
a.append(s)
while s != "end":
   i = 1
   j = 0
   while i < len(a):
      if s != a[len(a) - 1 - i]:
         i = i + 1
      elif s == a[len(a) - 1 - i]:
         a.pop()
         i = i + 1
   j = j + 1
   s = raw_input()
   a.append(s)
i = 0
while i < len(a) - 1:
   print a[i]
   i = i + 1
