#!/usr/bin/env python

import sys

a = []
s = raw_input()
arg = sys.argv[1]
i = 0
j = len(arg)
n = 0
while s != "end":
   while j < len(s) and s[i:j] != arg:
      i = i + 1
      j = j + 1
   if s[i:j] == arg:
      print s
   n = n + 1
   i = 0
   j = len(arg)
   s = raw_input()
