#!/usr/bin/env python

s = raw_input()
i = 0
total = 0
while s != "end":
   while s[i] != ":":
      i = i + 1
   print s[:i]
   i = 0
   s = raw_input()
