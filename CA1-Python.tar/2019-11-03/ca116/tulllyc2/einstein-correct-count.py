#!/usr/bin/env python

s = raw_input()
i = 1
n = 3
total = 0
while s != "end":
   while s[i:n] != "py":
      i = i + 1
      n = n + 1
   if s[n + 1:] == "correct":
      total = total + 1
   n = 3
   i = 1
   s = raw_input()
print total
