#!/usr/bin/env python3

import sys


def main():

    for line in sys.stdin:
        nums = line.split()
        a, b, c = int(nums[0]), int(nums[1]), int(nums[2])
        roots = root(a, b, c)
        if roots != "None":
            print("r1 = {}, r2 = {}".format(roots[0], roots[1]))
        else:
            print("None")
def root(a, b, c):
    first = (-b + (b ** 2 - (4 * a * c)) ** 0.5) / (2 * a)
    second = (-b - (b ** 2 - (4 * a * c)) ** 0.5) / (2 * a)
    if b ** 2 - (4 * a * c) >= 0:
        return first, second
    return "None"

if __name__ == '__main__':
    main()
