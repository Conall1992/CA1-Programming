#!/usr/bin/env python3

import re
import sys

# phone = findall(r"\b(\d{2}[\s, -]\d{7})\b", s)
p = r"\b(\d{2}[\s-]\d{7})\b"
phone = p
e = r"[a-z.]+@[a-z.]+.[a-z]+"
email = e
d = r"\d+[-/s]\d+[-/s][\d]+"
date = d
l = r"\d{2}\s[A-Z][a-z]+\s\d{2}"
ldate = l
