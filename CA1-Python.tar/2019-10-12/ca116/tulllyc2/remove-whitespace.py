#!/usr/bin/env python

s = raw_input()
length = len(s)
t = ""
i = 0
n = 0
while i < len(s):
   if s[i] == " ":
      s = s[:i] + s[i + 1:]
   else:
      i = i + 1
print s
