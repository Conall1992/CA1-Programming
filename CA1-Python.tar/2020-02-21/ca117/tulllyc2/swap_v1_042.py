#!/usr/bin/env python3

import sys

# def main():
#     ndict = {"a" : 4, "b" : 7, "c" : 10}
#     d = swap_keys_values(ndict)
#     print(d.items())

def swap_keys_values(ndict):
    items = sorted(ndict.items(), key=lambda value: value[1])
    ndict = {}

    for item in items:
        ndict[item[1]] = item[0]
    return ndict

# if __name__ == '__main__':
#     main()
