#!/usr/bin/env python3

import sys

# def main():
#     ndict = {'a' : 4, 'b' : 7, 'c' : 10, 'd' : 7}
#     d = swap_unique_keys_values(ndict)
#     print(d.items())

def swap_unique_keys_values(ndict):
    items = (sorted(ndict.items(), key=lambda value: value[1]))
    lis = [w for w in ndict.values()]
    ndict = {}
    for item in items:
        if int(lis.count(item[1])) != 2:
            ndict[item[1]] = item[0]
    return ndict

# if __name__ == '__main__':
#     main()
