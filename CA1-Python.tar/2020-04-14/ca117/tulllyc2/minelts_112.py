from priority_queue_112 import PQ
import sys


def main():
    m = int(sys.argv[1])
    pq = PQ()

    for n in sys.stdin:
        n = int(n)

        if pq.size() < m:
            pq.insert(n)
            continue

        if n < pq.d[1]:
            pq.delMax()
            pq.insert(n)

    while not pq.is_empty():
        print(pq.delMax())


if __name__ == '__main__':
    main()
