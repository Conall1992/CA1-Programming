#!/usr/bin/env python3

import sys

def main():
    d = {}
    for line in sys.stdin:
        name = " ".join(line.split()[0:-1])
        number = line.split()[-1:]
        average = sum([int(n) if n != "X" else 0 for n in "".join(number).split(",")])
        d[name] = average / 6
    for (k, v) in sorted(d.items(), key=lambda value: value[1], reverse=True):
        print("{} {:.1f}".format(k, v))

if __name__ == '__main__':
    main()
