#!/usr/bin/env python3

import sys

def main():
    vowels = "aeiou"

    for line in sys.stdin:
        nline = (line.lower())
        for e in nline:
            if e not in vowels:
                nline = nline.replace(e, "0")
        if ("".join(nline.split("0"))) == vowels:
            print(line.strip())


if __name__ == '__main__':
    main()
