#!/usr/bin/env python3

import sys

def main():
    n = int(sys.argv[2])
    word = sys.argv[1]
    word = list(word.strip())
    i = 0
    while i < n:
        letter = word[0]
        word.remove(letter)
        word.append(letter)
        i = i + 1

    print("".join(word))

if __name__ == '__main__':
    main()
