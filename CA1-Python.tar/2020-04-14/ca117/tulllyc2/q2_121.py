#!/usr/bin/env python3

import sys

def main():

    line1 = sys.stdin.readline().split()
    line2 = sys.stdin.readline().split()

    zipped = list(zip(line1, line2))

    i = 0
    indexes = []
    for (k, v) in zipped:
        if k == v:
            indexes.append(zipped.index((k, v)))
            zipped[zipped.index((k, v))] = 0

    print(indexes)

if __name__ == '__main__':
    main()
