#!/usr/bin/env python3

import sys

def main():

    for line in sys.stdin:
        word = list(line.strip())
        for i in range(1, len(word) - 1):
            if word[i].isupper():
                word[i] = " " + word[i].lower()
        print("".join(word))

if __name__ == '__main__':
    main()
