#!/usr/bin/env python3

import sys

def main():
    line = sys.stdin.readline()
    a, b = list(line.split()[0]), list(line.split()[1])
    for char in a:
        if char in b:
            index = a.index(char)
            break

    for i in range(0, len(b)):
        if i == index:
            print("".join(a))
        else:
            print("." * index + b[i] + "." * (len(a) - index - 1))

if __name__ == '__main__':
    main()
