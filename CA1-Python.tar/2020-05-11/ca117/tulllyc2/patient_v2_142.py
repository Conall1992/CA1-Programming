class Patient(object):

    def __init__(self, name, age, doctor, medications=[]):

        self.name = name
        self.age = age
        self.doctor = doctor
        self.medications = medications

    def __str__(self):

        line1 = "Name: {}".format(self.name)
        line2 = "Age: {}".format(self.age)
        line3 = "Doctor: {}".format(self.doctor)
        line4 = "Medications: {}".format(", ".join(self.medications))
        return "\n".join([line1, line2, line4, line3])
