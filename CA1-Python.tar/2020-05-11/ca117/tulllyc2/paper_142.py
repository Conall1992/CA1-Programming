#!/usr/bin/env python3

import sys

def main():

    Player1 = "Player 1 wins"
    Player2 = "Player 2 wins"

    for line in sys.stdin:
        p1, p2 = line.split()[0], line.split()[1]

        if p1 == p2:
            print("Draw")
        elif p1 == "scissors":
            if p2 == "rock":
                print(Player2)
            elif p2 == "paper":
                print(Player1)
        elif p1 == "rock":
            if p2 == "paper":
                print(Player2)
            elif p2 == "scissors":
                print(Player1)
        elif p1 == "paper":
            if p2 == "scissors":
                print(Player2)
            elif p2 == "rock":
                print(Player1)
if __name__ == '__main__':
    main()
