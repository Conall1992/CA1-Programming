class Patient(object):

    def __init__(self, name, age, doctor):

        self.name = name
        self.age = age
        self.doctor = doctor

    def __str__(self):

        line1 = "Name: {}".format(self.name)
        line2 = "Age: {}".format(self.age)
        line3 = "Doctor: {}".format(self.doctor)
        return "\n".join([line1, line2, line3])

class Ward(object):

    def __init__(self, d=None):
        if d is None:
            self.d = {}

    def add(self, other):
        self.d[other.name] = other

    def remove(self, name):
        del self.d[name]

    def lookup(self, name):
        if name in self.d.keys():
            return self.d[name]
        return None

    def __str__(sorted):
        return d.items()
