#!/usr/bin/env python3

import sys

def main():

    for line in sys.stdin:
        a = list(line.strip())
        unique = []
        total = 0
        for char in a:
            if char not in unique:
                unique.append(char)

        for char in line:
            if len(unique) > 2:
                total += 1
                unique.pop()
        print(total)

if __name__ == '__main__':
    main()
