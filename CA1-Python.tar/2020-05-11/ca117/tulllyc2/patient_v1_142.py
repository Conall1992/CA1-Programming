class Patient(object):

    def __init__(self, name, age, doctor):

        self.name = name
        self.age = age
        self.doctor = doctor

    def __str__(self):

        line1 = "Name: {}".format(self.name)
        line2 = "Age: {}".format(self.age)
        line3 = "Doctor: {}".format(self.doctor)
        return "\n".join([line1, line2, line3])
