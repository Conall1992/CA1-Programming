#!/usr/bin/env python

import sys

words = sys.stdin.readlines()
d = {}
flag = False
i = 0

while i < len(words) and not flag:
   if words[i].rstrip() not in d:
      d[words[i].rstrip()] = True
   elif words[i].rstrip() in d:
      flag = True
   i += 1

if flag:
   print "snap:", words[i - 1].rstrip()
