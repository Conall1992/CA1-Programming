#!/usr/bin/env python

import sys

words = sys.stdin.readlines()

fruit = {

    "apple": True,
    "pear": True,
    "orange": True,
    "banana": True,
    "cherry": True,
}

i = 0
while i < len(words):
    if words[i].rstrip() in fruit:
        sys.stdout.write(words[i])
    i += 1
