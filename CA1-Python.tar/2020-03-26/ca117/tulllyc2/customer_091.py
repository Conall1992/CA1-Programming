class Customer(object):

    interest = 0

    def __init__(self, name, balance, line1, line2, line3):

        self.n = name
        self.b = balance
        self.ogb = balance
        self.one = line1
        self.two = line2
        self.three = line3

    def owes(self):
        n = self.b * (1 - self.interest)
        return n

    def __str__(self):

        return "{}\n{}\n{}\n{}\nBalance: {:.2f}\nDiscount: {:.0f}%\nAmount due: {:.2f}".format(self.n, self.one, self.two, self.three, self.b, self.interest * 100, self.owes())

class ValuedCustomer(Customer):
    interest = 0.10
