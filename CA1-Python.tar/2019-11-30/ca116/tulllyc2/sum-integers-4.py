#!/usr/bin/env python

import sys

a = []

j = 0
i = 1
total = 0

while i < len(sys.argv):
   with open(sys.argv[i]) as fd:
      line = fd.read()
      test = line.split()
      while j < len(test):
         total = total + int(test[j])
         j += 1
   j = 0
   i = i + 1
print total
