#!/usr/bin/env python 

import sys

a = []
s = raw_input()
arg = sys.argv[1]
i = len(arg)
j = 0
while s != "end":
   while i <= len(s):
      if s[i - len(arg):i] == arg:
         a.append(s)
      i = i + 1
   s = raw_input()
print a

