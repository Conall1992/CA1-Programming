#!/usr/bin/env python


i = 0
j = 0
n = 0
while i < 10:
   s = raw_input()
   while j < len(s) and s[j] != "+":
      j = j + 1
   print int(s[:j]) + int(s[j:])
   j = 0
   i = i + 1
