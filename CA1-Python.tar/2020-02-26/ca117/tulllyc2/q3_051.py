#!/usr/bin/env python3

import sys

def main():
    words = sys.stdin.readlines()
    for word in words:
        capitals = [char if char.isupper() else "0" for char in word]
        split_capitals = "".join((capitals)).split("0")
        max_cap = max(split_capitals, key=len)
        print(max_cap)

if __name__ == '__main__':
    main()
