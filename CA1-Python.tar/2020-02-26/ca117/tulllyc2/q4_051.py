#!/usr/bin/env python3

import sys

def main():
    lines = sys.stdin.readlines()
    nums = sorted([int(num) for num in lines])
    print("Mean: {0:.1f}".format(mean(nums)))
    print("Median: {:.1f}".format(median(nums)))


def mean(nums):
    mean = sum(nums) / len(nums)
    return mean
def median(nums):
    if len(nums) % 2 == 1:
        median = nums[len(nums) // 2]
    else:
        median = (nums[len(nums) // 2] + nums[(len(nums) // 2) - 1]) / 2
    return median

if __name__ == '__main__':
    main()
