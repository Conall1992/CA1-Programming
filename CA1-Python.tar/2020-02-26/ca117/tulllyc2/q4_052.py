#!/usr/bin/env python3

import sys
def main():
	d = {}
	p = {}
	lines = sys.stdin.readlines()
	tokens = line.rsplit(maxsplit=1)
	food, calories = token[0], int(token[1])
	d[food] = calories
	for line in lines
		name, foods = tokens[0], token[1:]
		p[name] = 0
		total = 0
		for food in foods:
			if food in d:
				p[name] += int(d[food])
			else:
				p[name] += 100
