#!/usr/bin/env python3

import sys

def main():
	d = {}
	lines = sys.stdin.readlines()
	
	for line in lines:
		try:
			tokens = line.split()
			names, times = tokens[0], tokens[1:]
			print(times)
			d[names] = (min(times, key=highspeed))
		except:
			break
	fastest = min(d, key=lambda value: (value[1]))
	print(fastest, ":", d[fastest])

def highspeed(times):
	return int(times.split(":")[0] * 60) + int(times.split(":")[1])

if __name__ == '__main__':
	main()
