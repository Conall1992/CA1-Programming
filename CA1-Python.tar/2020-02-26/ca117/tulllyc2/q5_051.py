#!/usr/bin/env python3

import sys

def main():
    d = {}
    lines = sys.stdin.readlines()

    for line in lines:
        tokens = line.strip().split()
        name, times = tokens[0], tokens[1:]
        try:
            d[name] = min(times, key=highspeed)
        except:
            continue
    winner, fastest = min(d.items(), key=tuple)
    print(winner, ":", d[winner])

def highspeed(times):
    [m, s] = times.split(":")
    return int(m * 60) + int(s)

def tuple(t):
    return highspeed(t[-1])

if __name__ == '__main__':
    main()
