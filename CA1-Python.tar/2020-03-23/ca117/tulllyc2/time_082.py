class Time(object):

    count = 0

    def __init__(self, hour=0, minute=0, second=0):
        self.hour = hour
        self.minute = minute
        self.second = second
        Time.count += 1

    def __eq__(self, other):
        return ((self.hour, self.minute, self.second) ==
                (other.hour, other.minute, other.second))

    def __add__(self, other):
        return (self.seconds_to_time(self.time_to_seconds() + other.time_to_seconds()))

    def __gt__(self, other):
        return self.time_to_seconds() > other.time_to_seconds()

    def __iadd__(self, other):
        n = self + other
        self.hour, self.minute, self.second = n.hour, n.minute, n.second
        return self

    def __str__(self):
        return ('The time is {:02d}:{:02d}:{:02d}'.format(self.hour, self.minute, self.second))

    def time_to_seconds(self):
        return self.hour * 60 * 60 + self.minute * 60 + self.second

    @classmethod
    def seconds_to_time(cls, s):
        # these can be replaced by divmod(q, r) ands returns the (quotient, remainder)
        minute, second = (s // 60, s % 60)
        hour, minute = (minute // 60, minute % 60)
        overflow, hour = (hour // 24, hour % 24)
        return cls(hour, minute, second)
