#!/usr/bin/env python3

import sys

file_name = sys.argv[1]
total = 0
biggest = 0
score = []

try:
    with open(file_name) as fd:
        contents = fd.readlines()
        for num in contents:
            if int(num[0:2].strip()) > int(biggest):
                biggest = int(num[0:2].strip())
                name = num[2:]

        print("Best student:", name)
        print("Best mark:", biggest)
except:
    print("Invalid mark", num[0:2], "encountered. Exiting.")
