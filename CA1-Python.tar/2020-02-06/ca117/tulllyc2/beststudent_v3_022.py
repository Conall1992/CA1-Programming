#!/usr/bin/env python3

import sys

file_name = sys.argv[1]
total = 0
biggest = 0
score = []

with open(file_name) as fd:
    contents = fd.readlines()
    for num in contents:
        try:
            if int(num[0:2].strip()) > int(biggest):
                biggest = int(num[0:2].strip())
                name = num[2:]
        except:
            print("Invalid mark", num[0:2], "encountered. Skipping.")

print("Best student:", name.strip())
print("Best mark:", biggest)
