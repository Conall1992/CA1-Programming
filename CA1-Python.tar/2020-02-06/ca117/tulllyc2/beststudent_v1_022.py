#!/usr/bin/env python3

import sys

file_name = sys.argv[1]
total = 0
name = []
score = []

try:
    with open(file_name) as fd:
        contents = fd.readlines()
    for line in contents:
        name.append(" ".join(line.split()[1:]))
        score.append(line.split()[0])
    max_value = max(score)
    index = score.index(max_value)
    print("Best student:", name[int(index)])
    print("Best mark:", max_value)
except:
    print("hi")
