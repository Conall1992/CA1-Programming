#!/usr/bin/env python

n = raw_input()
prev = int(n)
servers = 0

while n != "end":
    if (int(n) - prev) < 1000:
        servers = servers + 1
    prev = int(n)
    n = raw_input()
print servers
