#!/usr/bin/env python

import os

files = os.listdir(".")
i = 0
while i < len(files):
   if files[i][len(files[i]) - 4:] == ".bak":
      os.unlink(files[i])
   i = i + 1
