#!/usr/bin/env python

import os

files = os.listdir(".")
i = 0

while i < len(files):
   with open(files[i]) as file_name:
      if file_name.read(1):
         if files[i][len(files[i]) - 3:] == ".py":
            print files[i]
   i = i + 1
