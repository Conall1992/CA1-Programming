#!/usr/bin/env python

import os

files = os.listdir(".")
i = 0

while i < len(files):
   if files[i][len(files[i]) - 4:] != ".bak":
      file_name = files[i]
      with open(files[i]) as fd:
         with open(file_name + ".bak", "w") as back_file:
            back_file.write(fd.read())
   i = i + 1
