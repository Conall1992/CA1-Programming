#!/usr/bin/env python3

import sys

a = []
first_line = sys.stdin.readline().split()
# print(first_line)
x, y = first_line[0], first_line[1]
# print(y)
lines = sys.stdin.readlines()
lines = [line.strip() for line in lines]
text = "".join(lines)
elements = list(text)

j = 0
for i in range(0, len(elements)):
    if elements[i] == "-":
        elements[i] = str(i)
        a.append(elements[i])
        j += 1

alone = []
for char in a:
    if str(int(char) + 1) in a:
        continue
    if str(int(char) - 1) in a:
        continue
    if str(int(char) - int(y) + 1) in a:
        continue
    if str(int(char) + int(y) + 1) in a:
        continue
    else:
        alone.append(char)

c = []
e =[]

for char in a:
    if str(int(char) - 1) not in a and str(int(char) - 1) not in alone:
        c.append(char)
for char in c:
    if str(int(char) - (int(y))) in a and str(int(char) - (int(y))) not in alone:
        e.append(char)  

# c = [char for char in a if int(a.index(char) + 1) < len(a) and ((int(a[a.index(char) + 1]) - int(char) == 1) or int(char) - int(a[a.index(char) - 1]) == 1)]
# e = [char for char in a if int(a.index(char) + 1) < len(a) and (int(a[a.index(char) + 1]) - int(char) == int(y))]
# f = [char for char in c if str(int(char) - int(y)) in c or str(int(char) + int(y) ) in c] 
# g = [char for char in f if int(f.index(char) + 1) < len(f) and (int(f[f.index(char) + 1]) - int(char) != 1)]
# h = [char for char in a if char not in e and char not in c]
    # elif elements[i] == "-" and ( elements[i - 20] == "-" or (elements[i + 1] == "-" or elements[i - 1]) == "-"):
    #     elements[i] == str(j)   

# print(alone)
# print(a)
# print(c)
# print(e)
print(len(set(alone).union(set(e))))
# # print(f)
# # print(g)
# # print(h)
