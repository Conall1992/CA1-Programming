from stack_092 import Stack

def add(a, b):
    return a + b
def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    return a / b

def sqrt(a):
    return a ** 0.5

def n(a):
    return a * -1

binops = {"+": add, "-": subtract, "/": divide, "*": multiply}
uniops = {"n": n, "r": sqrt}

def calculator(line):
    s1 = Stack()
    line = line.split()
    for char in line:
        if char in binops.keys() and not s1.is_empty():
            b = s1.pop()
            a = s1.pop()
            s1.push(binops[char](a, b))

        elif char in uniops.keys():
            s1.push(uniops[char](s1.pop()))
        else:
            s1.push(float(char))
    return s1.top()
