#!/usr/bin/env python3

import sys

a = []
first_line = sys.stdin.readline().split()
# print(first_line)
x, y = first_line[0], first_line[1]
# print(y)
lines = sys.stdin.readlines()
text = "".join(lines)
elements = list(text)
j = 0
for i in range(0, len(elements) - 1):
    if elements[i] == "-":
        elements[i] = str(i)
        a.append(elements[i])
        j += 1
b = [char for char in a if int(a.index(char) + 1) < len(a) and (int(a[a.index(char) + 1]) - int(char) == 1 or int(a[a.index(char) - 1]) - int(char) == -1)]
b = sorted(b, key=int)
c = [char for char in b if int(b.index(char) + 1) < len(b) and int(b[b.index(char) + 1]) - 1 != int(char)]
e = [char for char in a if char not in b and char not in c ]
d = [char for char in c if int(c.index(char) + 1) < len(c) and int(c[c.index(char) + 1]) - int(10) != int(char)]

    # elif elements[i] == "-" and ( elements[i - 20] == "-" or (elements[i + 1] == "-" or elements[i - 1]) == "-"):
    #     elements[i] == str(j)    
# print("".join(elements))
# print(a)
# print(b)
# print(c)
# print(e)
if len(e) > 1:
    print(len(d) + len(e) - 1)
else:
    print(len(d) + len(e) - 1)