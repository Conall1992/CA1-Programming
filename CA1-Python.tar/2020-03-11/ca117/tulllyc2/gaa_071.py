class Score(object):

    def __init__(self, goals=0, points=0):
        self.points = points
        self.goals = goals

    def greater_than(self, other):
        return self.score2points() > other.score2points()

    def less_than(self, other):
        return self.score2points() < other.score2points()

    def equal_to(self, other):
        return self.score2points() == other.score2points()

    def score2points(self):
        return int(self.points) + int(self.goals) * 3
