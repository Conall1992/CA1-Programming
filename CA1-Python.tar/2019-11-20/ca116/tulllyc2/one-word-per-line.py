#!/usr/bin/env python

import sys

line = sys.stdin.read()
join = "\n".join(line.split())
print join
