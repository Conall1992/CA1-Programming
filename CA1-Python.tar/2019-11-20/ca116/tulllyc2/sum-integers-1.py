#!/usr/bin/env python

import sys

i = 0
total = 0
line = sys.stdin.readline()
while 1 < len(line):
   total = total + int(line)
   line = sys.stdin.readline()
print total
