#!/usr/bin/env python

import sys


with open("irish-dobs.txt") as fd:
   with open("american-dobs.txt", "w") as f:
      line = fd.readline()
      while 0 < len(line):
         date = line.split()[0].split("/")
         day = (date[0])
         month = (date[1])
         year = (date[2])
         date = month + "/" + day + "/" + year
         test = date + ":" + " ".join(line.split()[1:])
         s = test.split(":")
         n = " ".join(s)
         f.write(n + "\n")
         line = fd.readline()
