#!/usr/bin/env python

import sys

line = sys.stdin.readline()
while 1 < len(line):
   split = line.split("/")
   s = split[len(split) - 1]
   print s[0:len(s) - 1]
   line = sys.stdin.readline()
