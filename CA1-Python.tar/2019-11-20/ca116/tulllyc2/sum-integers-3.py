#!/usr/bin/env python

import sys

file_name = sys.argv[1]

i = 1
total = 0

while i < len(sys.argv):
   with open(sys.argv[i]) as fd:
      line = fd.readline()
      while 0 < len(line):
         total = total + int(line)
         line = fd.readline()
   i = i + 1
print total
