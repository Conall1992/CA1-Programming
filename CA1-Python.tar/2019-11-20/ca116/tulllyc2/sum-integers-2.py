#!/usr/bin/env python

import sys

file_name = sys.argv[1]
total = 0

with open(file_name) as fd:
   line = fd.readline()
   while 0 < len(line):
      total = total + int(line)
      line = fd.readline()
print total
