car = r"\b(\d{2}[12]\s(?:C|CE|CN|CW|D|DL|G|KE|KK|KY|L|LD|LH|LM|LS|MH|MN|MO|OY|RN|SO|T|W|WH|WX|WW])\s[1-9]\d{0,5})\b"
