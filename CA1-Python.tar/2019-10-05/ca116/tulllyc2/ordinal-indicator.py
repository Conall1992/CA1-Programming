#!/usr/bin/env python

n = input()
if n % 2 == 0 and (n - 2) % 10 == 0 and (n - 2) % 10 == 0 and n % 10 != 12:
   print "nd"
elif ((n % 2 == 1 and (n - 1) % 10 == 0) or n == 1) and n % 10 != 11 and n != 11:
   print "st"
elif (n % 5  == 3 or n == 3) and n % 10 != 13 and n != 13:
   print "rd"
elif n == 11 or n == 12 or n == 13:
   print "th"
else:
   print "th"
