#!/usr/bin/env python

import sys
n = 20
x1 = int(sys.argv[1])
y1 = int(sys.argv[2])


plot = {}

i = 0
while i < int(sys.argv[3]):
   plot[(str(x1 + i)) + "-" + str(y1)] = True
   i = i + 1
i = 0
j = 1
while i < int(sys.argv[3]) - 1:
   plot[(str(x1)) + "-" + str(y1 + j)] = True
   plot[(str(x1 + int(sys.argv[3]) - 1)) + "-" + str(y1 + j)] = True
   j = j + 1
   i = i + 1
i = 0
while i < int(sys.argv[3]):
   plot[(str(x1 + i)) + "-" + str(y1 + int(sys.argv[3]) - 1)] = True
   i = i + 1


print " " + "-" * n

i = 0
while i < n:
   y = n - i - 1
   output = []

   x = 0
   while x < n:
      key = str(x) + "-" + str(y)
      if key in plot:
         output.append("*")
      else:
         output.append(" ")
      x = x + 1

   print "|" + "".join(output) + "|"
   i = i + 1

print " " + "-" * n
