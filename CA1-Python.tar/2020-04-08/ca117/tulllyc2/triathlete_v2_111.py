class Triathlete(object):

    def __init__(self, name, ID):
        self.name = name
        self.tid = ID
        self. d = {}

    def add_time(self, discipline, time):
        self.d[discipline] = int(time)

    def get_time(self, s):
        discipline = self.d[s]
        return discipline

    def __str__(self):
        name = "Name: {:s}".format(self.name)
        ID = "ID: {}".format(self.tid)
        time = "Race time: {}".format(sum(self.d.values()))
        return "\n".join([name, ID, time])
