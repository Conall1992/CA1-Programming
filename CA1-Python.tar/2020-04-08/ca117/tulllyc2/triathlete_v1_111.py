class Triathlete(object):

    def __init__(self, name, ID):
        self.name = name
        self.tid = ID

    def __str__(self):
        name = "Name: {:s}".format(self.name)
        ID = "ID: {}".format(self.tid)
        return "\n".join([name, ID])
