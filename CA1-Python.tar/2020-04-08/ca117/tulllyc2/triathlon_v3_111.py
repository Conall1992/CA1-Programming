class Triathlete(object):

    def __init__(self, name, ID):
        self.name = name
        self.tid = ID
        self. d = {}

    def add_time(self, discipline, time):
        self.d[discipline] = int(time)

    def get_time(self, s):
        discipline = self.d[s]
        return discipline

    def __eq__(self, other):
        return sum(self.d.values()) == sum(other.d.values())

    def __lt__(self, other):
        return sum(self.d.values()) < sum(other.d.values())

    def __gt__(self, other):
        return sum(self.d.values()) > sum(other.d.values())

    def __str__(self):
        name = "Name: {:s}".format(self.name)
        ID = "ID: {}".format(self.tid)
        time = "Race time: {}".format(sum(self.d.values()))
        return "\n".join([name, ID, time])


class Triathlon(object):

    def __init__(self, d=None):
        if d is None:
            self.d = {}

    def add(self, other):
        self.d[int(other.tid)] = other

    def remove(self, ID):
        del self.d[ID]

    def lookup(self, ID):
        if ID in self.d.keys():
            return self.d[int(ID)]
        return None

    def best(self):
        return min([str(v) for v in sorted(self.d.values(), key=lambda x: sum(x.d.values()))])

    def worst(self):

        return max([str(v) for v in sorted(self.d.values(), key=lambda x: sum(x.d.values()))])

        return "\n".join([str(v) for v in sorted(self.d.values(), key=lambda x: x.name)])
