class BankAccount(object):

    next_account_number = 16555232
    account_type = "General"

    def __init__(self, forename, surname, balance):
        self.forename = forename
        self.surname = surname
        self.balance = balance
        self.account_number = self.next_account_number
        BankAccount.next_account_number += 1

    def lodge(self, amount):
        self.balance += amount

    def withdraw(self, amount):
        if amount <= self.balance:
            self.balance -= amount
        else:
            print ("Insufficient funds available")

    def __str__(self):
        name = "Name: {} {}".format(self.forename, self.surname)
        number = "Account number: {}".format(self.account_number)
        account = "Account type: {}".format(self.account_type)
        balance = "Balance: {:.2f}".format(self.balance)
        return "\n".join([name, number, account, balance])

class CurrentAccount(BankAccount):

    overdraft = -1000.00

    account_type = "Current"

    def withdraw(self, amount):
        if self.balance - amount >= self.overdraft:
            self.balance -= amount
        else:
            print ("Insufficient funds available")

    def __str__(self):
        over = "Overdraft: {:.2f}".format(self.overdraft)
        return "\n".join([super().__str__(), over])

class SavingsAccount(BankAccount):

    interest_rate = 0.01

    account_type = "Savings"

    def apply_interest(self):
        self.balance *= (1 + self.interest_rate)

    def withdraw(self, amount):
        if self.balance - amount >= 0:
            self.balance -= amount
        else:
            print ("Insufficient funds available")

    def __str__(self):
        interest = "Interest rate: {}".format(self.interest_rate)
        return "\n".join([super().__str__(), interest])
