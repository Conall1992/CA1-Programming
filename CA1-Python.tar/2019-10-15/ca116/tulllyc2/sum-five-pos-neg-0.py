#!/usr/bin/env python

n = 1
psum = 0
nsum = 0
i = 0
while not n == 0:
   n = input()
   if n < 0:
      nsum = nsum + n
   elif n > 0:
      psum = psum + n
   i += 1
print nsum, psum
