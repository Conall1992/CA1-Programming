#!/usr/bin/env python

curr = input()
prev = 0
i = 0
while i < 5:
   prev = curr
   curr = input()
   if curr > prev:
      print "higher"
   elif prev > curr:
      print "lower"
   else:
      print "equal"
   i += 1
