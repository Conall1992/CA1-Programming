#!/usr/bin/env python

x = input()
y = input()
if y > x:
   t = x
   x = y
   y = t
while x % y > 0:
   if x > y:
      t = x % y
      x = y
      y = t
print y
