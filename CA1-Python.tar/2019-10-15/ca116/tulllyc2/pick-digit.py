#!/usr/bin/env python

n = input()
p = input()
t = str(n)
a = t[(p + 1) * -1]
print a
