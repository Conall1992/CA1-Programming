#!/usr/bin/env python

n = input()
x = -1
y = 0
i = 0
nseq = -1
print y
print x
while i < n - 2:
   if nseq % 2 == 0 or nseq == 0:
      x = x - 2
      nseq = x
      print nseq
   elif (nseq % 2) != 0:
      y = y + 2
      nseq = y
      print nseq
   i += 1
