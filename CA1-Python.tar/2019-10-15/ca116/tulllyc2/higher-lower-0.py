#!/usr/bin/env python

curr = input()
prev = 0

while not curr == 0:
   prev = curr
   curr = input()
   if curr > prev and curr != 0:
      print "higher"
   elif prev > curr and curr != 0:
      print "lower"
   elif curr == prev:
      print "equal"
