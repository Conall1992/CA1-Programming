#!/usr/bin/env python

n = 1
sum = 0
while not n == 0:
   n = input()
   if n < 0:
      sum = sum + (n * -1)
   else:
      sum = sum + n
print sum
