#!/usr/bin/env python

n = input()
a = ""
while n > 0:
   m = n % 2
   a = str(n % 2) + a
   n = n / 2
print a
