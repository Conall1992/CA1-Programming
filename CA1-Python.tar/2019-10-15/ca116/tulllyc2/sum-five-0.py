#!/usr/bin/env python

n = input()
sum = n
while not n == 0:
   n = input()
   sum = sum + n
print sum
