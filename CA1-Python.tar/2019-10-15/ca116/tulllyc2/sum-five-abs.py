#!/usr/bin/env python

sum = 0
i = 0
while i < 5:
   n = input()
   if n < 0:
      sum = sum + (n * -1)
   elif n > 0:
      sum = sum + n
   i += 1
print sum
