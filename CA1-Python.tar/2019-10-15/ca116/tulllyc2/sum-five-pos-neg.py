#!/usr/bin/env python

psum = 0
nsum = 0
i = 0
while i < 5:
   n = input()
   if n < 0:
      nsum = nsum + n
   elif n > 0:
      psum = psum + n
   i += 1
print nsum, psum
