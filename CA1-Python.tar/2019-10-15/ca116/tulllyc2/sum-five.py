#!/usr/bin/env python

sum = 0
i = 0
while i < 5:
    n = input()
    sum = sum + n
    i += 1
print sum
