#!/usr/bin/env python

total = 0
i = 0
while i < 10:
   total = total + input()
   i = i + 1
print total / 10
