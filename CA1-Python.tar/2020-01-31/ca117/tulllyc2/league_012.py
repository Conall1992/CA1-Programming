#!/usr/bin/env python3

import sys

starts = ["10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"]
lines = sys.stdin.readlines()
# maxLine = len(max(lines., key=len))

allclubs = []
for line in lines:
    club = " ".join(line.split()[1:-8])
    allclubs.append(club)
maxLine = len(max(allclubs, key=len))

print("{:<3s} {:{}s} {:>2s} {:>3s} {:>3s} {:>3s} {:>3s} {:>3s} {:>3s} {:>3s}".format("POS", "CLUB", maxLine, "P", "W", "D", "L", "GF", "GA", "GD", "PTS"))


for line in lines:
    words = line.split()
    clubs = (line.split()[1:-8])
    for club in clubs:
        if club in words:
            words.remove(club)

    pos = words[0]
    p = words[1]
    w = words[2]
    d = words[3]
    l = words[4]
    GF = words[5]
    GA = words[6]
    GD = words[7]
    PTS = words[8]
    club = " ".join(line.split()[1:-8])
    print("{:>3s} {:{}s} {:>2s} {:>3s} {:>3s} {:>3s} {:>3s} {:>3s} {:>3s} {:>3s}".format(pos, club.rstrip(), maxLine, p, w, d, l, GF, GA, GD, PTS.strip()))
