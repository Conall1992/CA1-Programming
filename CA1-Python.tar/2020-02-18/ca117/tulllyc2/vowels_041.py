#!/usr/bin/env python3

import sys
from string import punctuation

def main():
    contents = sys.stdin.read().strip().lower().split()
    words = "".join(contents)

    vowels = set("aeiou")

    d = {}
    highest = 0
    for e in vowels:
        d[e] = words.count(e)
        if d[e] > highest:
            highest = d[e]

    for (k, v) in sorted(d.items(), key=lambda value: (value[1], value[0]), reverse=True):
        print('{} : {:>{}}'.format(k, v, len(str(highest))))

# def values(value): not needed if you know how lambda works
#     return value[1], value[0]
if __name__ == '__main__':
    main()
