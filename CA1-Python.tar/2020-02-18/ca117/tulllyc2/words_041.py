#!/usr/bin/env python3

import sys
from string import punctuation

contents = sys.stdin.read().strip().lower().split()
lis = [word.strip(punctuation) for word in contents]
words = set(contents)
d = {}
for e in words:
    d[e.strip(punctuation)] = lis.count(e.strip(punctuation))
maxnum = max(d, key=len)

for (k, v) in sorted(d.items()):
    print('{:} : {}'.format(k, v))
