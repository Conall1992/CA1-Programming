#!/usr/bin/env python3

def l2d(fd):
    d = {}
    lis = fd.readline().split()
    lis2 = fd.readline().split()
    for e in lis:
        d[e] = lis2[int(lis.index(e))]
    return d
