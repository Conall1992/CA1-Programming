#!/usr/bin/env python3

import sys

d = {}

file_name = sys.argv[1]

with open(file_name) as fd:
    contents = fd.readlines()
    for line in contents:
        line = line.split()
        d[line[0]] = line[1]

lines = sys.stdin.readlines()
for name in lines:
    if name.strip() in d.keys():
        print("Name:", name.strip())
        print("Phone:", d[name.strip()])
    else:
        print("Name:", name.strip())
        print("No such contact")
