#!/usr/bin/env python3

import sys
from string import punctuation

contents = sys.stdin.read().strip().lower().split()
lis = [word.strip(punctuation) for word in contents]
words = set(lis)
d = {}
for e in words:
    if lis.count(e) >= 3 and len(e) > 3:
        d[e] = lis.count(e)

maxnum = max(d, key=len)
for (k, v) in sorted(d.items()):
    print('{:>{}} : {:>2}'.format(k, len(maxnum), v))
