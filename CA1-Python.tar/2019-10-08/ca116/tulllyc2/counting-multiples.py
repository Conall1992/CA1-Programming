#!/usr/bin/env python

n = input()
m = input()
t = 1
k = 1
i = 0
while i < n:
   t = m * k
   print t
   k = k + 1
   i = i + 1
