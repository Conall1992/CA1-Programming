#!/usr/bin/env python

n = input()
i = n
while i > 0:
   i = i - 1
   print i
