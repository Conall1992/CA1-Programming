#!/usr/bin/env python

n = input()
i = 0
m = 0
while i < n:
   m = m + 1
   if m % 3 == 0 and m % 5 != 0:
      print "fizz"
   elif m % 5 == 0 and m % 3 != 0:
      print "buzz"
   elif m % 5 == 0 and m % 3 == 0:
      print "fizz-buzz"
   else:
      print m
   i = i + 1
