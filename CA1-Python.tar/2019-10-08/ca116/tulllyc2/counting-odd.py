#!/usr/bin/env python

n = input()
t = 1
m = 1
i = 0
while i < n:
   t = 2 * m - 1
   print t
   m = m + 1
   i = i + 1
