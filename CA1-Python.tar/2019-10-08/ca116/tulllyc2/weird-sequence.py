#!/usr/bin/env python

n = input()
i = 0
m = 0
while i < (n - 3):
   if i < n - 3:
      print m
      m = (m + 1) * -1
   if i < n - 3:
      print m
      m = (m - 1) * -1
      i = i + 1
