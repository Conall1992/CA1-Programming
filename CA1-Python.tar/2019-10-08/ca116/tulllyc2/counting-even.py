#!/usr/bin/env python

n = input()
t = 0
i = 0
while i < n:
   t = t + 2
   print t
   i = i + 1
