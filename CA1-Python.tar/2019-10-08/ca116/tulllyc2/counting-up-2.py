#!/usr/bin/env python

n = input()
i = 1
while i < n + 1:
   print i
   i = i + 1
