#!/usr/bin/env python

n = input()
t = 1
m = 1
i = 0
while i < n:
   t = 7 * m
   print t
   m = m + 1
   i = i + 1
