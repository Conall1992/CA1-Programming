#!/usr/bin/env python3

import sys

def set(line):
    lis = []
    for char in line:
        if char.isalnum():
            lis.append(char)
    return lis == lis[::-1]

def main():
    for line in sys.stdin:
        line = line.strip().lower()
        print(set(line))
if __name__ == '__main__':
    main()
