#!/usr/bin/env python3

import sys

tokens = []

total = 0
for line in sys.stdin:
    nline = line.split()
    total = total + len(nline)

print(total)
