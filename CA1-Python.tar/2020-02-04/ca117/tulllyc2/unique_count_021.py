#!/usr/bin/env python3

import sys
import string

tokens = []

total = 0
for line in sys.stdin:
    nline = line.split()
    for word in nline:
        for c in string.punctuation:
            word = word.replace(c, "")
        word = word.lower()
        if word not in tokens and word.isalnum():
            tokens.append(word)

print(len(tokens))
