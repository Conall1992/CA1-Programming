#!/usr/bin/env python

if __name__ == "__main__":
   a = []
   b = []

li = []
i = 0
c = raw_input()
while c != "end":
   a.append(int(c))
   c = raw_input()
i = 0
d = raw_input()
while d != "end":
   b.append(int(d))
   d = raw_input()
i = 0
j = 0
while i < len(a) and i < len(b):
   if a[i] < b[j]:
      li.append(a[i])
      i = i + 1
   else:
      li.append(b[j])
      j = j + 1
li = li + b[j:] + a[i:]
i = 0
while i < len(li):
   print li[i]
   i = i + 1
