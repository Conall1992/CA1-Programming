#!/usr/bin/env python

n = input()
s = ""
hex = "abcdef"
base = 2

while n > 0:
   m = n % base
   if m == "10"
      s = m + s
      n = n / 2
   elif m == "11"
      s = m + s
      n = n / 2
   elif m == "12"
      s = m + s
      n = n / 2
   elif m == "13"
      s = m + s
      n = n / 2
   elif m == "14"
      s = m + s
      n = n / 2
   elif m == "15"
      s = m + s
      n = n / 2
print s
