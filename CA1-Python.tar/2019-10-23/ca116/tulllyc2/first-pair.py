#!/usr/bin/env python

s = raw_input()
t = 1
i = 0
while i < len(s) - 1 and not s[i] == s[t]:
   i = i + 1
   t = i + 1
if i < len(s) - 1:
   print s[i:t + 1]
