#!/usr/bin/env python

s = raw_input()
t = 0
j = 0
i = 0
n = 0


while i < len(s) and not ("0" < s[i] and s[i] < "9"):
   i = i + 1
   j = i
while j < len(s) and not s[j] == " ":
   j = j + 1
   n = j
while n < len(s) and not ("0" < s[n] and s[n] < "9"):
   n = n + 1
   t = n
while t < len(s) and not s[t] == " ":
   t = t + 1
if n < len(s) - 1:
   print s[n - 1:t], n - 1
