#!/usr/bin/env python

s = raw_input()
i = 0
n = 1
while i < len(s) - n and not s[i] != s[len(s) - n]:
   i = i + 1
   n = n + 1
if s[i] == s[len(s) - n]:
   print "palindrome"
