#!/usr/bin/env python3

import sys

lis = [line.strip() for line in sys.stdin]

print("Words with q but no u:", [line.strip() for line in lis if (line.lower().count("q") > line.lower().count("qu"))])
