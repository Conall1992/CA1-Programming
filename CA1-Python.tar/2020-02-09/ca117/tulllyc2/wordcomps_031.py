#!/usr/bin/env python3

import sys

vowels = ["a", "e", "i", "o", "u"]
lis = [line.strip() for line in sys.stdin]
e = []

def main():
    print("Words containing 17 letters:", [line for line in lis if len(line) == 17])
    print("Words containing 18+ letters:", [line for line in lis if len(line) > 17])
    print("Shortest word containing all vowels:", min([line for line in lis if (all(char in line.lower() for char in vowels))], key=len))
    print("Words with 4 a's:", [line for line in lis if line.lower().count("a") == 4])
    print("Words with 2+ q's:", [line for line in lis if line.lower().count("q") > 1])
    print("Words containing cie:", [line for line in lis if "cie" in (line.lower())])
    print("Anagrams of angle:", [line for line in lis if "".join(sorted((line.lower()))) == ("aegln") and line.lower() != "angle"])
    print("Words ending in iary:", len([line for line in lis if line.endswith("iary")]))
    print("Words with most e's:", E(e, lis))

def E(e, lis):
    es = max([line for line in lis if "e" in line.lower()], key=countE)
    numE = es.count("e")
    return [line for line in lis if line.count("e") == numE]

def countE(line):
    return line.count("e")
if __name__ == '__main__':
    main()
