#!/usr/bin/env python3

import sys

n = int(sys.argv[1])

lis = range(1, n + 1)
prime = range(2, n)

print("Multiples of 3:", [num for num in lis if not num % 3])
print("Multiples of 3 squared:", [(num ** 2) for num in lis if not num % 3])
print("Multiples of 4 doubled:", [num * 2 for num in lis if not num % 4])
print("Multiples of 3 or 4:", [num for num in lis if not (num % 3 and num % 4)])
print("Multiples of 3 and 4:", [num for num in lis if not (num % 3 or num % 4)])
print("Multiples of 3 replaced:", [num if num % 3 else 'X' for num in lis])
print("Primes:", [num for num in prime if 0 not in [num % d for d in range(2, num)]])
