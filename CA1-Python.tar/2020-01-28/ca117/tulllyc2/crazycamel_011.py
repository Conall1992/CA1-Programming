#!/usr/bin/env python3

import sys

def lastLetter(s):
   s = s[0:len(s) - 1] + s[len(s) - 1].capitalize()
   return s

def main():
   i = 0
   for line in sys.stdin:
      words = line.split()
      for word in words:
         words[i] = lastLetter(words[i])
         i = i + 1
      words = " ".join(words)
      i = 0
      print(words)

if __name__ == '__main__':
   main()
