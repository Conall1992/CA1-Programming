#!/usr/bin/env python3

import sys


def middle(s):
   if len(s) % 2 == 1:
      s = s[int(len(s) / 2)]
      return s
   else:
      return "No middle character!"

def main():
    lines = sys.stdin.readlines()
    for line in lines:
        mid = middle(line.strip())
        print(mid)
if __name__ == '__main__':
    main()
