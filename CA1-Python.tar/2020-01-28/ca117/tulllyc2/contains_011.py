#!/usr/bin/env python3

import sys

def set(s):
    lis = s.split()
    lis[0] = "".join(sorted(lis[0].lower()))
    lis[1] = "".join(sorted(lis[1].lower()))
    return lis
def main():
    for line in sys.stdin:
        line = line
        words = set(line)
        print(words[0] in words[1])
if __name__ == '__main__':
    main()
