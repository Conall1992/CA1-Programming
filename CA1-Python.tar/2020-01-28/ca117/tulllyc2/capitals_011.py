#!/usr/bin/env python3

import sys


def capatilise(s):
   if len(s) > 1:
      s = s[0].capitalize() + s[1:len(s) - 1] + s[len(s) - 1].capitalize()
   return s

def main():
    lines = sys.stdin.readlines()
    for line in lines:
        capital = capatilise(line.strip())
        if len(capital) > 1:
           print(capital)
if __name__ == '__main__':
    main()
