#!/usr/bin/env python3

import sys

def main():
    lines = sys.stdin.readlines()
    for line in lines:
        line = line.strip()
        words = line.split()
        print(words[0].lower() in words[1].lower())

if __name__ == '__main__':
    main()
