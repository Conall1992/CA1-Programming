#!/usr/bin/env python3

import sys

def replaceNum(s):
   for char in s:
      if char.isdigit():
         s = s.replace(char, ".")
   return s

def splits(s):
   words = s.split(".")
   return words

def main():
   for line in sys.stdin:
      line = replaceNum(line)
      words = splits(line)
      print(words[0].capitalize(), words[1].capitalize())
if __name__ == '__main__':
   main()
