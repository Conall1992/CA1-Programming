#!/usr/bin/env python3

import sys

def lastLetter(s):
   return s.capitalize()

def main():
   i = 0
   for line in sys.stdin:
      words = line.split()
      for word in words:
         words[i] = word.capitalize()
         i = i + 1
      words = " ".join(words)
      i = 0
      print(words)

if __name__ == '__main__':
   main()
