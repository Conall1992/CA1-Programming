#!/usr/bin/env python3

import sys

def convert(b, n):
   return int(b, n)

def main():
   for line in sys.stdin:
      words = line.split()
      print(convert((words[0]), int(words[1])))

if __name__ == '__main__':
   main()
