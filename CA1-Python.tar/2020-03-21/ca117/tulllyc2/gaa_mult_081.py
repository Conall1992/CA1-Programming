class Score(object):

    def __init__(self, goals=0, points=0):
        self.points = points
        self.goals = goals

    def __gt__(self, other):
        return self.score2points() > other.score2points()

    def __lt__(self, other):
        return self.score2points() < other.score2points()

    def __ge__(self, other):
        return self.score2points() >= other.score2points()

    def __le__(self, other):
        return self.score2points() <= other.score2points()

    def __eq__(self, other):
        return self.score2points() == other.score2points()

    def __add__(self, other):
        return Score(self.goals + other.goals, self.points + other.points)

    def __sub__(self, other):
        return Score(self.goals - other.goals, self.points - other.points)

    def __iadd__(self, other):
        self.goals += other.goals
        self.points += other.points
        return self

    def __isub__(self, other):
        self.goals -= other.goals
        self.points -= other.points
        return self

    def score2points(self):
        return self.points + self.goals * 3

    def __mul__(self, n):
        return Score(self.goals * n, self.points * n)

    def __rmul__(self, n):
        return Score(n * self.goals, n * self.points)

    def __imul__(self, n):
        self.points *= n
        self.goals *= n
        return self

    def __str__(self):
        return "{} goal(s) and {} point(s)".format(self.goals, self.points)
