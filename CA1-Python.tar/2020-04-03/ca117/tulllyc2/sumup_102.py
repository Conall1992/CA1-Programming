def sumup(n):
    if n == 0:
        return 0
    return sumup(n - 1) + n
