from stack_092 import Stack


right = ")}]"
left = "({["
d = {v: k for k, v in zip(left, right)}

def matcher(s):
    s1 = Stack()

    for char in s:
        if char in left:
            s1.push(char)
        try:

            if char in right and s1.top() == d[char]:
                s1.pop()
        except:

            return False

    return (s1.is_empty())
