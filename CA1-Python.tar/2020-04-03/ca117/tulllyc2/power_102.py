def power(n, p):
    if p == 0:
        return 1
    elif n == 0:
        return 0
    return n * power(n, p - 1)
