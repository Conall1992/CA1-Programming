def minimum(lis):

    if len(lis) == 1:
        return lis[0]

    if lis[0] <= minimum(lis[1:]):
        return lis[0]

    else:
        return minimum(lis[1:])
