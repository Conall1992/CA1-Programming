def reverse_list(lis):
    if len(lis) == 0:
        return []
    else:
        return lis[-1:] + reverse_list(lis[:-1])
