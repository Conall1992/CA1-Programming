#!/usr/bin/env python

n = input()
a = str(n)
c = a[-1:]
b = a[-2:]
if c == "1" and b != "11":
   print "st"
elif c == "2" and b != "12":
   print "nd"
elif c == "3" and b != "13":
   print "rd"
else:
   print "th"
