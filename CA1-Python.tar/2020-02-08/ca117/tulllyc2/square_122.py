#!/usr/bin/env python3

import sys
import math

def main():
    lines = sys.stdin.readlines()
    cd = [x.strip().split(" ") for x in lines]

    x = distance(int(cd[0][0]), int(cd[0][1]), int(cd[1][0]), int(cd[1][1]))
    y = distance(int(cd[1][0]), int(cd[1][1]), int(cd[2][0]), int(cd[2][1]))
    z = distance(int(cd[2][0]), int(cd[2][1]), int(cd[0][0]), int(cd[0][1]))

    if x == y:
        third = [int(cd[1][0]), int(cd[1][1])]
        first = [int(cd[2][0]), int(cd[2][1])]
        second = [int(cd[0][0]), int(cd[0][1])]
    elif x == z:
        third = [int(cd[0][0]), int(cd[0][1])]
        first = [int(cd[2][0]), int(cd[2][1])]
        second = [int(cd[1][0]), int(cd[1][1])]
    else:
        third = [int(cd[2][0]), int(cd[2][1])]
        first = [int(cd[1][0]), int(cd[1][1])]
        second = [int(cd[0][0]), int(cd[0][1])]

    midpoint = [((first[0] + second[0])) / 2, (first[1] + second[1]) / 2]
    # print(midpoint)
    fourth = [first[0] + second[0] - third[0], first[1] + second[1] - third[1]]
    print(str(fourth[0]) + " " + str(fourth[1]))
    length = distance(first[0], first[1], third[0], third[1])

    # fourth = ( (first[0] ^ second[0]) ^ third[0], (first[1] + second[1]) - third[1])
    # fourth1 = [midpoint[0] + (length / 2), midpoint[1] + length / 2]
    # fourth2 = [midpoint[0] - length / 2, midpoint[1] - length / 2]
    # fourth3 = [midpoint[0] + length / 2, midpoint[1] - length / 2]
    # #  print(distance(fourth[0], fourth[1], third[0], third[1])) == (2 * length)
    # print(fourth)
    # #  print (distance(fourth1[0], fourth1[1], third[0], third[1])) == (2 * length)
    # print(fourth1[0], fourth1[1])
    # #  print (distance(fourth2[0], fourth2[1], third[0], third[1])) == (2 * length)
    # print(fourth2[0], fourth2[1])
    # print(fourth3[0], fourth3[1])

def distance(x1, y1, x2, y2):
    d = math.sqrt(((x2 - x1) ** 2 + (y2 - y1) ** 2))
    return d

if __name__ == '__main__':
    main()
