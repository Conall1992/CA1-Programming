#!/usr/bin/env python3

import sys

a = []
lines = sys.stdin.read()
lines = " ".join((lines.split("#")))
lines = (lines.split())
for e in lines:
    if lines.count(e) > 1 and (len(lines[lines.index(e) + 1]) != len(e) - 1 or len(lines[lines.index(e) + 1]) != len(e) + 1):
        a.append(e)
print(len((a)))