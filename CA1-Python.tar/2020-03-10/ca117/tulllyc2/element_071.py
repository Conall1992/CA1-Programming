#!/usr/bin/env python3

class Element(object):

    def __init__(self, n, e, s, b):
        self.e = e
        self.n = n
        self.s = s
        self.b = b

    def print_details(self):
        print("Number:", self.n)
        print("Name:", self.e)
        print("Symbol:", self.s)
        print("Boiling point:", self.b, "K")
