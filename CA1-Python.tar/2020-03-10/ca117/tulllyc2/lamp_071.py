#!/usr/bin/env python3

class Lamp(object):

    def __init__(self, on=False):
        self.on = on

    def turn_off():
        self.on = False
        
    def turn_on():
        self.on = True

    def toggle():
        if self.on == False:
            self.on = True:
        
        else:
            self.on = False


