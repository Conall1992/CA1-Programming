#!/usr/bin/env python3

import sys

def main():
    a = []
    twice = []
    i = 0
    lines = sys.stdin.readlines()
    cd = [x.split(" ") for x in lines]
    
    x = distance(int(cd[0][0]), int(cd[0][1]), int(cd[1][0]), int(cd[1][1]), a)
    y = distance(int(cd[1][0]), int(cd[1][1]), int(cd[2][0]), int(cd[2][1]), a)
    z = distance(int(cd[2][0]), int(cd[2][1]), int(cd[0][0]), int(cd[0][1]), a)
    
    if x == y:
        third = [int(cd[1][0]), int(cd[1][1])]
        first = [int(cd[2][0]), int(cd[2][1])]
        second = [int(cd[0][0]), int(cd[0][1])]
    elif y == z:
        third = (int(cd[2][0]), int(cd[2][1]))
        first = [int(cd[1][0]), int(cd[1][1])]
        second = [int(cd[0][0]), int(cd[0][1])]
    elif x == z:
        third = (int(cd[0][0]), int(cd[0][1]))
        first = [int(cd[2][0]), int(cd[2][1])]
        second = [int(cd[0][0]), int(cd[0][1])]
    print(str(abs(first[0] - third[0])), str(abs(first[1] - third[1])))

def distance(x1, y1, x2, y2, a):
    twice = []
    d = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
    return d

if __name__ == '__main__':
    main()
