#!/usr/bin/env python3

import sys

num = 0

for line in sys.stdin:
    try:
        num = int(line.strip())
        break
    except:
        print(line.strip(), "is not a number")
print("Thank you for", num)
