#!/usr/bin/env python3

import sys

def main():
    highest = 0
    try:
        with open(sys.argv[1]) as f:
            f = f.readlines()
        f = [x.strip("\n") for x in f]

        for line in f:
            try:
                line = line.strip().split()
                mark = int(line[0])
                name = " ".join(line[1:])
                if mark > highest:
                    highest = mark
                    best = name.strip()
            except:
                print('Invalid mark {} encountered. Skipping.'.format(line[0].strip()))
                line = " ".join(line)

    except:
        print('The file {} could not be found'.format(sys.argv[1]))

    print('Best student:', best)
    print('Best mark:', highest)

if __name__ == '__main__':
    main()
