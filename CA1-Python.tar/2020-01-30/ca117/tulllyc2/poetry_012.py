#!/usr/bin/env python3

import sys
import math

def main():
    lines = sys.stdin.readlines()
    maxLine = len(max(lines, key=len)) - 1
    for line in lines:
        print("{:^{}s}".format(line.strip(), maxLine))

if __name__ == '__main__':
    main()
