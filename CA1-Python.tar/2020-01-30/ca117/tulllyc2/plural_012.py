#!/usr/bin/env python3

import sys

def main():
    for line in sys.stdin:
        new_line = security(line.strip())
        print(new_line)

def security(s):
    es = ["x", "sh", "ch", "s", "z", "o"]
    y = ["ay", "ey", "oy", "iy", "uy"]
    if s.endswith(tuple(es)):
        s = s + "es"
    elif s.endswith("f"):
        s = s[0:len(s) - 1] + "ves"
    elif s.endswith("fe"):
        s = s[0:len(s) - 2] + "ves"
    elif (s.endswith("y")) and not (s.endswith(tuple(y))):
        s = s[0:len(s) - 1] + "ies"
    elif (s.endswith(tuple(y))):
        s = s + "s"
    else:
        s = s + "s"
    return s
if __name__ == '__main__':
    main()
