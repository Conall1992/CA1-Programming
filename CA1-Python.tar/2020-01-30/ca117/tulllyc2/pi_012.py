#!/usr/bin/env python

import sys

from math import pi

n = sys.argv[1]

print("{:.{}f}".format(pi, n))
