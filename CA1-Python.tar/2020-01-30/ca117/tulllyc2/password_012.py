#!/usr/bin/env python3

import sys

def main():
    for line in sys.stdin:
        count = security(line.strip())
        print(count)

def security(s):
    count = 0
    upper = False
    lower = False
    other = False
    digit = False

    for char in s:
        if char.isupper():
            upper = True
        elif char.islower():
            lower = True
        elif char.isdigit():
            digit = True
        else:
            other = True

    if upper:
        count = count + 1
    if lower:
        count = count + 1
    if digit:
        count = count + 1
    if other:
        count = count + 1

    return count
if __name__ == '__main__':
    main()
