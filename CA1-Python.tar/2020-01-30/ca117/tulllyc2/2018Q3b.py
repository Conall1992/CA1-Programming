#!/usr/bin/env python

def reverse(s):
   i = 0
   j = 1
   n = ""
   while i < len(s):
      n = n + s[len(s) - j]
      i = i + 1
      j = j + 1 
   print n
print type(reverse("hello"))
