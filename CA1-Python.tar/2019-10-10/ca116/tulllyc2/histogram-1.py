#!/usr/bin/env python

a = input()
b = input()
c = input()
d = input()
e = input()
f = input()
g = input()
h = input()
i = input()
j = input()
print "*" * a
print "*" * b
print "*" * c
print "*" * d
print "*" * e
print "*" * f
print "*" * g
print "*" * h
print "*" * i
print "*" * j
