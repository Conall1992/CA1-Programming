#!/usr/bin/env python

n = raw_input()
i = 0
while i < len(n):
   print n[len(n) - i - 1]
   i = i + 1
