#!/usr/bin/env python

s = raw_input()
n = input()
m = n - 1
print s + (("-" + s) * m)
