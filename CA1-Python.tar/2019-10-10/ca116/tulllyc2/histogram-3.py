#!/usr/bin/env python

n = raw_input()
m = 0
i = 0
while i < len(n):
   m = n[i]
   print "*" * int(n[i])
   i = i + 1
