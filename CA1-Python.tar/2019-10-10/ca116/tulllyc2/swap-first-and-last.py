#!/usr/bin/env python

t = raw_input()
print t[len(t) - 1] + t[1:len(t) - 1] + t[0]
