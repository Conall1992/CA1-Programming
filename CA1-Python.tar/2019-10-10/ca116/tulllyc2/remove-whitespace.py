#!/usr/bin/env python

s = raw_input()
t = len(s)
n = s.split()
print "".join(s.split())
