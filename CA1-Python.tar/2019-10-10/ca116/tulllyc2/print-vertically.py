#!/usr/bin/env python

n = raw_input()
i = 0
while i < len(n):
   print n[i]
   i = i + 1
