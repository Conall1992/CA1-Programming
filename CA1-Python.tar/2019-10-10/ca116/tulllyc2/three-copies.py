#!/usr/bin/env python

s = raw_input()
print s * 3
