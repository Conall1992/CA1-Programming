#!/usr/bin/env python

n = input()
i = 0
while i < n:
   m = input()
   print "*" * m
   i = i + 1
