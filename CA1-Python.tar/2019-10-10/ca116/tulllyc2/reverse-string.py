#!/usr/bin/env python

n = raw_input()
total = ""
i = 0
while i < len(n):
   total = total + n[len(n) - i - 1]
   i = i + 1
print total
