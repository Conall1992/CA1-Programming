#!/usr/bin/env python

s = raw_input()
n = len(s)
i = 0
while i < n:
   print s[i: n + 1]
   i = i + 1
