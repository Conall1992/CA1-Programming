#!/usr/bin/env python

if __name__ == "__main__":
   a = ["dog", "cat", "mouse"]

total = 0
i = 0
while i < len(a) and not ("a" <= a[i] and a[i] <= "z"):
   i = i + 1
if i < len(a):
   print a[i]
