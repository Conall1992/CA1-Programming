#!/usr/bin/env python

if __name__ == "__main__":
   a = ["dog", "cat", "mousepop"]

total = 0
i = 0
while i < len(a):
   if 6 <= len(a[i]):
      print a[i]
   i = i + 1
