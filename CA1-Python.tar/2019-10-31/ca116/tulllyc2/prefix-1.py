#!/usr/bin/env python

if __name__ == "__main__":
   a = ["dogcatpop", "cat", "mousepop"]
   s = "dog"

i = 0
while i < len(a):
   if a[i][0: len(s)] == s:
      print a[i]
   i = i + 1
