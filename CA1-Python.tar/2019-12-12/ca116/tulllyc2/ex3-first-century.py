#!/usr/bin/env python

import sys

lines = sys.stdin.readlines()

i = 0
while i < len(lines) and not (int(lines[i]) >= int(100)):
   i = i + 1

if i < len(lines):
   print lines[i].strip()
else:
   print "none"
