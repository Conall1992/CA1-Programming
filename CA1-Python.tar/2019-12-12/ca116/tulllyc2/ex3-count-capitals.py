#!/usr/bin/env python

import sys

count = 0
words = sys.stdin.readlines()

i = 0
j = 0

while i < len(words):
   while j < len(words[i]):
      if "A" <= words[i][j] and words[i][j] <= "Z":
         count = count + 1
      j = j + 1
   i = i + 1
   j = 0
print count
