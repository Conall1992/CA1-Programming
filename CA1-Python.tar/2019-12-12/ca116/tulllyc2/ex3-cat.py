#!/usr/bin/env python

import sys

file_name = sys.argv[1]

with open(file_name, "r") as fd:
   i = 0
   lines = fd.readlines()
   while i < len(lines):
      lines[i] = lines[i][0: len(lines[i]) - 1]
      print lines[i]
      i = i + 1
