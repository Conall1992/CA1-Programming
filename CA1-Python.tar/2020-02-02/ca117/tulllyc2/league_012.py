#!/usr/bin/env python3

import sys

lines = sys.stdin.readlines()
# maxLine = len(max(lines., key=len))
#list for clubs names
allclubs = []
for line in lines:
    #finds clubs name
    club = " ".join(line.split()[1:-8])
    #adds club name to a list
    allclubs.append(club)
# gets the length of the longest club name which is needed to format the table correctly
maxLine = len(max(allclubs, key=len))
#this prints out the tables's heading
print("{:<3s} {:{}s} {:>2s} {:>3s} {:>3s} {:>3s} {:>3s} {:>3s} {:>3s} {:>3s}".format("POS", "CLUB", maxLine, "P", "W", "D", "L", "GF", "GA", "GD", "PTS"))

for line in lines:
    #splits line based on spaces
    words = line.split()
    #finds the clubs name and splits it  based on space
    clubs = (line.split()[1:-8])
    for club in clubs:
        #for each word that is in the club name do the following
        if club in words:
            #this two lines remove the club name form the the og input
            words.remove(club)
#with the club name removed we can now assign variables to each value
    pos = words[0]
    p = words[1]
    w = words[2]
    d = words[3]
    l = words[4]
    GF = words[5]
    GA = words[6]
    GD = words[7]
    PTS = words[8]
# clubs name
    club = " ".join(line.split()[1:-8])
#this prints out the table's content
    print("{:>3s} {:{}s} {:>2s} {:>3s} {:>3s} {:>3s} {:>3s} {:>3s} {:>3s} {:>3s}".format(pos, club.rstrip(), maxLine, p, w, d, l, GF, GA, GD, PTS.strip()))
