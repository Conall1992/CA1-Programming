#!/usr/bin/env python

import sys

i = 0
j = 0
arg = sys.argv[1]
count = 0
s = raw_input()
while arg[i] != "=":
   i = i + 1
if arg[j:i] == "City":
   count = 1
if arg[j:i] == "State":
   count = 2
if arg[j:i] == "LatD":
   count = 3
if arg[j:i] == "LatS":
   count = 4
if arg[j:i] == "NS":
   count = 5
if arg[j:i] == "LonD":
   count = 6
if arg[j:i] == "LonM":
   count = 7
if arg[j:i] == "LonS":
   count = 8
if arg[j:i] == "EW":
   count = 9
j = 0
i = 0
k = 0
while i < len(s) and i < count:
   j = i
   while i < len(s) and s[i] != ",":
      i = i + 1
   i = i + 1
   k = k + 1
print s[j:i - 1]
