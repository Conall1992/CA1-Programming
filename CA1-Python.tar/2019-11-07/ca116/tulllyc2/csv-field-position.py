#!/usr/bin/env python

import sys

i = 0
j = 0
count = 0
s = raw_input()
while i < len(s) and s[j:i - 1] != sys.argv[1]:
   j = i
   while i < len(s) and s[i] != ",":
      i = i + 1
   count = count + 1
   i = i + 1
print count - 1
