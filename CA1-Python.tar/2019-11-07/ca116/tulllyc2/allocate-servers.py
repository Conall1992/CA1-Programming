#!/usr/bin/env python

s = raw_input()
count = 0
while s != "end":
   copy = s
   if int(s) - 100 <= copy:
      count = count + 1
   s = raw_input()
print count
