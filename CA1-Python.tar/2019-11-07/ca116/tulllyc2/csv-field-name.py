#!/usr/bin/env python

import sys

i = 0
j = 0
count = 0
s = raw_input()
while count <= int(sys.argv[1]) and i < len(s):
   j = i
   while i < len(s) and s[i] != ",":
      i = i + 1
   count = count + 1
   i = i + 1
print s[j:i - 1]
