#!/usr/bin/env python
 
a = []
b = []
li = []
s = raw_input()
r = raw_input()
 
while s != "end":
   a.append(int(s))
   s = raw_input()
while r != "end":
   b.append(int(r))
   r = raw_input()
li = a[0:] + b[0:]
i = 0
while i < len(li):
   j = i + 1
   p = i
   while j < len(li):
      if li[j] < li[p]:
         p = j
      j = j + 1
   tmp = li[p]
   li[p] = li[i]
   li[i] = tmp
   i = i + 1

print li