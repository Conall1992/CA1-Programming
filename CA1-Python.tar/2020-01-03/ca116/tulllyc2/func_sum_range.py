#!/usr/bin/env python

import func_bsearch


def sum_range(a, low, high):
   total = 0
   q = low
   low1 = func_bsearch.bsearch(a, q)
   if low <= a[0]:
      low1 = 0
   while low1 < len(a) and a[low1] < high:
      total = total + a[low1]
      low1 = low1 + 1
   return total
