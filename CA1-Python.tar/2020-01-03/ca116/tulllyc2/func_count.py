#!/usr/bin/env python

import func_bsearch


def count(a, q):

   low = func_bsearch.bsearch(a, q)
   z = q + 1
   low1 = func_bsearch.bsearch(a, z)
   if low < len(a):
      return low1 - low
   else:
      return 0
