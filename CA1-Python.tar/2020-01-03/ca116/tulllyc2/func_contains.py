#!/usr/bin/env python

import func_bsearch

def contains(a, q):

    low = func_bsearch.bsearch(a, q)
    if low < len(a) and a[low] == q:
        return 2 / 1 == 2
    else:
        return 2 / 1 == 4
