#!/usr/bin/env python3

import sys
a = []
pairs = []
for line in sys.stdin:
    temp = []
    for i in range(0, len(line) - 2):

        if line[i] == line[i + 1] and line[i] in "aeiou" and line[i] != line[i - 1]:
            temp.append(line[i])
    if len(pairs) < len(temp):
        if len(a) > 0:
            a.pop()
            a.append(line)
        else:
            a.append(line)
    else:
        pairs = temp

print(a[0].strip())
