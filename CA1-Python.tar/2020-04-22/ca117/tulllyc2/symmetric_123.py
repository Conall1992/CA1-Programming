#!/usr/bin/env python3

import sys

def main():
    i = 1
    even = []
    odd = []

    for line in sys.stdin:
        if i % 2 == 1:
            odd.append(line)
        else:
            even.append(line)
        i += 1
    for word in sorted(odd, key=len):
        print(word.strip())

    for word in sorted(even, reverse=True, key=len):
        print(word.strip())
if __name__ == '__main__':
    main()
