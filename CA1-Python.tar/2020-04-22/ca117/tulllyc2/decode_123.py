#!/usr/bin/env python3

import sys

vowels = "aeiou"

for line in sys.stdin:
    lis = []
    i = 0
    while i < len(line) - 1:
        if line[i] in "aeiou":
            lis.append(line[i])
            i += 3
        else:
            lis.append(line[i])
            i += 1
    print("".join(lis))
