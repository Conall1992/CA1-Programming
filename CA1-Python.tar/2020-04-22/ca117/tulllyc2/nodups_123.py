#!/usr/bin/env python3

import sys
punc = [".", ",", "!"]

def main():

    lis = []
    lower = []
    for line in sys.stdin:
        test = []
        for word in line.split():
            if word.endswith(tuple(punc)):
                other = word[0:-1]
            else:
                other = word
            if other.lower() in lower:
                test.append(".")
            else:
                test.append(word)
                lower.append(other.lower())
        lis.append(" ".join(test))
    print("\n".join(lis))

if __name__ == '__main__':
    main()
