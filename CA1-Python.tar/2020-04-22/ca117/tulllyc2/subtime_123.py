#!/usr/bin/env python3

import sys

def main():
    for line in sys.stdin:
        curr_time = line.split()[0]
        hour, minute = int(curr_time.split(":")[0]), int(curr_time.split(":")[1])

        n = int(line.split()[1])
        print(time_to_seconds(hour, minute, n))

def time_to_seconds(hour, minute, n):
    seconds = hour * 60 * 60 + minute * 60 - n * 60
    return seconds_to_time(seconds)

def seconds_to_time(s):
    minute, second = divmod(s, 60)
    hour, minute = divmod(minute, 60)
    overflow, hour = divmod(hour, 24)
    return "{:02d}:{:02d}".format(hour, minute)


if __name__ == '__main__':
    main()
