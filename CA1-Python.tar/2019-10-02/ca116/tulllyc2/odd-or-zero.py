#!/usr/bin/env python

n = input()
t = n * (n % 2)
print t
