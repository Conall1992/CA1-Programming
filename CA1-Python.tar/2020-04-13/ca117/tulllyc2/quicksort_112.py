def quicksort(A, p, r):
    def partition(A, first, last):

        q = j = first

        while j < last:

            if A[j] <= A[last]:
                A[q], A[j] = A[j], A[q]
                q += 1

            j += 1

        A[q], A[last] = A[last], A[q]

        return q

    if r <= p:
        return

    q = partition(A, p, r)
    quicksort(A, p, q - 1)
    quicksort(A, q + 1, r)
