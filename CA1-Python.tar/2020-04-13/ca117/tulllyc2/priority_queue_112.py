class PQ(object):

    def __init__(self, d=None):
        if d is None:
            self.d = []

    def insert(self, e):
        self.d.append(e)

    def delMax(self):
        if not self.d.is_empty():
            return self.d.remove(max(self.d))

    def getMax(self):
        if not self.d.is_empty():
            return max(self.d)

    def is_empty(self):
        return len(self.d) == 0
    
    def size(self):
        return len(self.d)
