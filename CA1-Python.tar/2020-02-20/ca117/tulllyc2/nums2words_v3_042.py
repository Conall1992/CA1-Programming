#!/usr/bin/env python3

import sys

file_name = sys.argv[1]


numbers = sys.stdin.readlines()


def main():
    d = {}
    d = create_dict(d)
    for line in numbers:
        changed = change(line.split(), d)
        print(" ".join(changed))

def change(split, d):

    for i in range(0, len(split)):
        if split[i].isdigit():
            split[i] = d[split[i]]
        else:
            split[i] = "unknown"
    return split

def create_dict(d):
    with open(file_name) as fd:
        lines = fd.readlines()
        i = 0
        for line in lines:
            d[str(i)] = line.split()[1]
            i += 1
    return d
if __name__ == '__main__':
    main()
