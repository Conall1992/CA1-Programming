#!/usr/bin/env python3

import sys

lis = []
lines = sys.stdin.readlines()
for line in lines:
    line = line.strip()
    lis.append(line[len(line) - 1])

print("The probability of nothing is {:.4f}%".format(((lis.count("0") / len(lis)) * 100)))
print("The probability of one pair is {:.4f}%".format(((lis.count("1") / len(lis)) * 100)))
print("The probability of two pairs is {:<.4f}%".format(((lis.count("2") / len(lis)) * 100)))
print("The probability of three of a kind is {:`<.4f}%".format(((lis.count("3") / len(lis)) * 100)))
print("The probability of a straight is {:<.4f}%".format(((lis.count("4") / len(lis)) * 100)))
print("The probability of a flush is {:<.4f}%".format(((lis.count("5") / len(lis)) * 100)))
print("The probability of a full house is {:<.4f}%".format(((lis.count("6") / len(lis)) * 100)))
print("The probability of four of a kind is {:<.4f}%".format(((lis.count("7") / len(lis)) * 100)))
print("The probability of a straight flush is {:<.4f}%".format(((lis.count("8") / len(lis)) * 100)))
print("The probability of a royal flush is {:<.4f}%".format(((lis.count("9") / len(lis)) * 100)))
