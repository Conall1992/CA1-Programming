#!/usr/bin/env python3

import sys

digits = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten"]
teens = ["eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"]
twenty_100 = ["twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety", "hundred"]

numbers = sys.stdin.readlines()

def main():
    d = {}
    d = create_dict(d)
    for line in numbers:
        changed = change(line.split(), d)
        print(" ".join(changed))

def change(split, d):

    for i in range(0, len(split)):
        if split[i].isdigit():
            split[(i)] = d[split[i]]
        else:
            split[i] = "unknown"
    return split

def create_dict(d):
    d = {}
    for num in range(0, 101):
        if num // 10 == 0:
            d[str(num)] = digits[int(num)]
        elif num // 10 == 1:
            d[str(num)] = teens[int(num) % 10 - 1]
        elif num // 10 >= 2 and num // 10 < 10 and num % 10 != 0:
            d[str(num)] = twenty_100[num // 10 - 2] + "-" + digits[num % 10]
        elif num // 10 >= 2 and num // 10 < 10 and num % 10 == 0:
            d[str(num)] = twenty_100[num // 10 - 2]
        else:
            d[str(num)] = "one hundred"
    return d

if __name__ == '__main__':
    main()
