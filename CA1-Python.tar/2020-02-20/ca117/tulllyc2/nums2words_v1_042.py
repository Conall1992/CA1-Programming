#!/usr/bin/env python3

import sys

d = {"0": "zero", "1": "one", "2": "two", "3": "three", "4": "four", "5": "five", "6": "six", "7": "seven", "8": "eight", "9": "nine", "10": "ten"}
numbers = sys.stdin.readlines()


def main():

    for line in numbers:
        changed = change(line.split())
        print(" ".join(changed))

def change(split):

    for i in range(0, len(split)):
        if split[i].isdigit():
            split[i] = d[split[i]]
        else:
            split[i] = "unknown"
    return split

if __name__ == '__main__':
    main()
