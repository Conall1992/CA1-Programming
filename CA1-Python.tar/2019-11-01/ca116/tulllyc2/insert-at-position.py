#!/usr/bin/env python

a[p:p] = [v]
