#!/usr/bin/env python

a = []
b = []
c = []
d = []
s = raw_input()
i = 0
while not s == "end":
   a.append(int(s))
   s = raw_input()
n = input()
d.append(n)
i = 0
while i < len(a) and n > a[i]:
   b.append(a[i])
   i += 1
while i < len(a):
   c.append(a[i])
   i += 1
a = b + d + c
i = 0
while i < len(a):
   print a[i]
   i += 1
