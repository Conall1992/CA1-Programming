#!/usr/bin/env python

if __name__ == "__main__":
   a = [4, 5, 8, 89, 1, 3, 100]

curr_lowest = 0
prev_lowest = 0

while curr_lowest < len(a):
   if a[curr_lowest] < a[prev_lowest]:
      prev_lowest = curr_lowest
   curr_lowest += 1
print prev_lowest
