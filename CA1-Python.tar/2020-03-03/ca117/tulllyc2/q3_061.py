#!/usr/bin/env python3

import sys
s = sys.argv[1]
word = list(s)
i = 0
while i < len(word) - 1:
    word[i], word[i + 1] = word[i + 1], word[i]
    i += 2
print("".join(word))
