#!/usr/bin/env python3

import sys

passed = {}
failed = []
for line in sys.stdin:
    lis = line.split()
    club = " ".join(lis[:-5])
    try:
        points = [int(char) for char in lis[len(lis) - 5:]]
        passed[club] = str(sum(points))
    except:
        failed.append(club)
        continue
max_clubs = len(max(passed.keys(), key=len))
max_points = len(max(passed.values(), key=len))

for k, v in sorted(passed.items(), key=lambda values: int(values[1]), reverse=True):
        print("{:>{}}: {:>{}} points".format(k, max_clubs, v, max_points))
print("Disqualified:")
for line in failed:
    print(line)
