#!/usr/bin/env python3

import sys

for line in sys.stdin:
    lis = line.split()
    for char in lis:
        if char.isdigit() and lis.count(char) == 1:
            print(char)
            break
