#!/usr/bin/env python3

import sys

file_name = sys.argv[1]
s = sys.argv[2]

def main():
    d = {}
    scrapple = {}
    a = []
    d = dictionary(d)
    lines = sys.stdin.readlines()
    for line in lines:
        # print(sorted(list(line.strip())))
        # print(sorted(list(s.strip())))
        score = sum([d[char] for char in line.strip() if s.count(char) == line.count(char)])
        scrapple[line.strip()] = score
    test = max(scrapple.items(), key=lambda values: values[1])
    print(test[0] + ":", test[1])

def dictionary(d):
    d = {}
    with open(file_name) as fd:
        lines = fd.readlines()
        for line in lines:
            tokens = line.split()
            d[tokens[0]] = int(tokens[1])
        return d

if __name__ == '__main__':
    main()
