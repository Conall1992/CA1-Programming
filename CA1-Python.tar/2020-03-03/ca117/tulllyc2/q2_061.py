#!/usr/bin/env python3

import sys
lines = sys.stdin.readlines()
for line in lines:
    lis = [char if char in "nice" else "0" for char in line.lower()]
    join = "".join(lis)
    final_word = "".join(join.split("0"))
    if final_word == "nice":
        print(line.strip())
