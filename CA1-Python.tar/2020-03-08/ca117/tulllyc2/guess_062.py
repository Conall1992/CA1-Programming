from random import randint

top = 1000000
bottom = 0
z = randint(bottom, top)

def guess(g):
    if g == z:
        return 0
    elif g < z:
        return -1
    else:
        return 1

# Find z *efficiently* by calling guess() (and without peeking at z!)
def find():
    top = 1000000
    bottom = 0
    g = 500000
    guess2 = guess(g)
    while guess2 != 0:
        if guess2 == 0:
            return g
        if guess2 == -1:
            bottom = g
            g = ((bottom + top) // 2)
            guess2 = guess(g)
        if guess2 == 1:
            top = g
            g = (bottom + top) // 2
            guess2 = guess(g)
    return g
def main():
    a = find()
    if a == z:
        print('Correct!')
    else:
        print('Incorrect!')
    print('You said {:d} and answer is {:d}'.format(a, z))

if __name__ == '__main__':
    main()
