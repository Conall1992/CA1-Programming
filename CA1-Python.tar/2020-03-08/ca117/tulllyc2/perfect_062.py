#!/usr/bin/env python3

import sys

def main():
    for line in sys.stdin:
        ans = sumFac(int(line))
        print(ans)

def sumFac(n):
    sums = sum([int(i) for i in range(1, n // 2 + 1) if n % i == 0])
    perfect = isPerfect(sums, n)
    return perfect

def isPerfect(sums, n):
    return sums == n

if __name__ == '__main__':
    main()
