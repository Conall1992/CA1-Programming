#!/usr/bin/env python3

import sys

def main():

    words = ["".join(list(word.strip())) for word in sys.stdin]
    zipped = (list(zip(*words)))
    test = (["".join(list(e)) for e in zipped])
    test = sorted(test, key=str.lower)
    convertion = [list(word) for word in test]
    unzipped = ((list(zip(*convertion))))
    convertion2 = [list(word) for word in unzipped]
    for e in convertion2:
        print("".join(e).strip())


if __name__ == '__main__':
    main()
