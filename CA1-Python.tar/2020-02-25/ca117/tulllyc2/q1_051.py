#!/usr/bin/env python3

import sys

def main():
    word = sys.argv[1]
    word = list(word)
    final = swappy(word)
    print(final)


def swappy(lis):
    i = 0
    while i < len(lis) - 1:
        lis[i], lis[i + 1] = lis[i + 1], lis[i]
        i += 2
    return "".join(lis)


if __name__ == '__main__':
    main()
