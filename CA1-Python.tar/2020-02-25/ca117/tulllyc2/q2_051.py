#!/usr/bin/env python3

import sys

def main():
    words = sys.stdin.readlines()
    for word in words:
        s_word = list()
        new_word = [c.lower() for c in word if c.lower() in "evil"]
        if "".join(new_word) == "evil":
            print(word.strip())

if __name__ == '__main__':
    main()
