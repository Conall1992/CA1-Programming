#!/usr/bin/env python3

import sys

def main():
    words = [word.strip() for word in sys.stdin]
    len_words = []
    for word in words:
        len_words.append(int(len(word)))
    average_len = sum(len_words) / len((words))
    print("Average: {:.2f}".format(average_len))
    for word in words:
        if len(word) > average_len:
            print(word.strip())

if __name__ == '__main__':
    main()
