#!/usr/bin/env python3

import math
import sys

def main():
    d = {20: 1, 40: 2, 60: 3, 80: 4, 100: 5, 120: 6, 140: 7, 160: 8, 180: 9, 200: 10}
    score = []
    for line in sys.stdin:
        x, y = abs(int(line.split()[0])), abs(int(line.split()[1]))
        distance = (((x) ** 2 + (y) ** 2) ** 0.5)
        
        non_round = 200 - distance
        twentys = roundup(200 - distance)
       
        if twentys != 0 :
            if non_round == 200:
                score.append(11)
            elif distance == 20:
                score.append(11 - 1)
            else:
                score.append(d[twentys])
    print(sum(score)) 


def roundup(x):
    return int(math.ceil(x / 20.0)) * 20
if __name__ == '__main__':
    main()

