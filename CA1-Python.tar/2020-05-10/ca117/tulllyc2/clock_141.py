#!/usr/bin/env python3

import sys

def main():
    a = int(sys.stdin.readline())
    b = int(sys.stdin.readline())
    twh, tfh = time(a, b)
    if tfh == twh * -1:
        if tfh > 0:
            print(tfh)
        else:
            print(twh)
    elif abs(tfh) < abs(twh):
        print(tfh)
    elif abs(tfh) > abs(twh):
        print(twh)

def time(a, b):
    twh = b - a
    if b < a:
        tfh = (b + 12) - a
    else:
        tfh = b - (a + 12)
    return twh, tfh

if __name__ == '__main__':
    main()
