#!/usr/bin/env python

s = raw_input()
n = raw_input()
m = raw_input()
x = len(s)
y = len(n)
v = len(m)
if x > y and x > v:
   print s
elif y > x and y > v:
   print n
elif v > y and v > x:
   print m
