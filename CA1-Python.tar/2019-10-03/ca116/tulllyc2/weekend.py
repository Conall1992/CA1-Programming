#!/usr/bin/env python

x = input()
if x < 5 and 0 <= x:
   print "weekday"
else:
   print "weekend"
