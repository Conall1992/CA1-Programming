#!/usr/bin/env python

x = input()

if x != 2 and x % 2 == 0 or x % 3 == 0 and x != 3 or x == 1:
   print "not prime"
else:
   print "prime"
