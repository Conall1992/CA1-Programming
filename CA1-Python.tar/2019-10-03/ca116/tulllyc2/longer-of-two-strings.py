#!/usr/bin/env python

s = raw_input()
n = raw_input()
x = len(s)
y = len(n)
if x > y:
   print s
else:
   print n
