#!/usr/bin/env python

n = input()
if n % 2 == 0:
   n = n / 2
elif n != 2:
   n = 3 * n + 1
print n
