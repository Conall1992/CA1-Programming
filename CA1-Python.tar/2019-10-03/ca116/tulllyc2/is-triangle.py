#!/usr/bin/env python

a = input()
b = input()
c = input()
if a + b > c and c >= a and c >= b:
   print "yes"
elif a + c > b and b >= c and b >= a:
   print "yes"
elif b + c > a and a >= c and a >= b:
   print "yes"
else:
   print "no"
