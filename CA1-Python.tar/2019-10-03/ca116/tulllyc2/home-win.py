#!/usr/bin/env python

x = input()
y = input()
if x > y:
   print "Home win."
elif y > x:
   print "Away win."
elif y == x:
   print "Draw."
