#!/usr/bin/env python

a = []
b = []
s = raw_input()
r = raw_input()

while s != "end":
   a.append(int(s))
   s = raw_input()
while r != "end":
   a.append(int(s))
   r = raw_input()
i = 0
while i < len(a):
   j = i + 1
   p = i
   while j < len(a):
      if a[j] < a[p]:
         p = j
      j = j + 1
   tmp = a[p]
   a[p] = a[i]
   a[i] = tmp
   i = i + 1
i = 0
while i < len(b):
   j = i + 1
   p = i
   while j < len(b):
      if b[j] < b[p]:
         p = j
      j = j + 1
   tmp = b[p]
   b[p] = b[i]
   b[i] = tmp
   i = i + 1
i = 0
print a + b
