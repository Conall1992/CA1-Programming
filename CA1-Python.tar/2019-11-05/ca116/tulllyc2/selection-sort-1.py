#!/usr/bin/env python

a = []
s = raw_input()
p = 0
i = 0
while s != "end":
   a.append(int(s))
   s = raw_input()

while i < len(a):
   while a[i] < a[p]:
      p = i
   i = i + 1
print p
